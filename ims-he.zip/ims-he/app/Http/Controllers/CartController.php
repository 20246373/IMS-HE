<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\Product;
use App\Services\CartService;
use Illuminate\Http\Request;

// Customer cart (SDD 4.1 Cart & Checkout Module, cart part only). Guests are sent to login by auth:customer (UC19 includes UC01).
class CartController extends Controller
{
    public function __construct(private CartService $carts) {}

    public function index(Request $request)
    {
        $cart = $this->carts->cartFor($request->user('customer'));

        // Clamp quantities to current stock and flag price changes before showing the cart.
        $warnings = $this->carts->reconcile($cart);

        // Totals are recalculated from current prices on every view.
        $items = $cart->load('items.product')->items->sortBy('product.product_name');
        $total = $items->sum(fn (CartItem $i) => $i->quantity * $i->product->unit_price);

        return view('cart.index', ['items' => $items, 'total' => $total, 'warnings' => $warnings]);
    }

    public function store(Request $request, Product $product)
    {
        $data = $request->validate(['quantity' => 'required|integer|min:1|max:9999']);

        $item = $this->carts->add($request->user('customer'), $product, $data['quantity']);

        // The product page adds in the background so the shopper stays on the page; it only needs the new cart count.
        if ($request->expectsJson()) {
            return response()->json([
                'message' => "{$product->product_name} added to your cart.",
                'count' => (int) $item->cart->items()->sum('quantity'),
            ]);
        }

        return redirect()->route('customer.cart.index')->with('status', "{$product->product_name} added to your cart.");
    }

    public function update(Request $request, CartItem $item)
    {
        $this->authorizeItem($request, $item);
        $data = $request->validate(['quantity' => 'required|integer|min:1|max:9999']);

        $this->carts->update($item, $data['quantity']);

        // The cart page saves - / + changes in the background and only needs the recalculated numbers back.
        if ($request->expectsJson()) {
            $items = $item->cart->items()->with('product')->get();

            return response()->json([
                'quantity' => $item->quantity,
                'subtotal' => $item->quantity * $item->product->unit_price,
                'total' => $items->sum(fn (CartItem $i) => $i->quantity * $i->product->unit_price),
                'count' => $items->sum('quantity'),
            ]);
        }

        return redirect()->route('customer.cart.index')->with('status', 'Cart updated.');
    }

    public function destroy(Request $request, CartItem $item)
    {
        $this->authorizeItem($request, $item);

        $this->carts->remove($item);

        return redirect()->route('customer.cart.index')->with('status', 'Item removed from your cart.');
    }

    // A customer can only change lines in their own cart.
    private function authorizeItem(Request $request, CartItem $item): void
    {
        abort_unless((int) $item->cart->customer_id === (int) $request->user('customer')->customer_id, 404);
    }
}
