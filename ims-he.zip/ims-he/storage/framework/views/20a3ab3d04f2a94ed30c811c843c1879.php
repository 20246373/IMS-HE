<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('heading'); ?>Welcome, <?php echo e(auth()->user()->displayName()); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<p class="page-sub">Signed in as <strong><?php echo e(auth()->user()->role); ?></strong>.</p>
<?php $__empty_1 = true; $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
 <?php echo $__env->make('dashboard._'.$widget, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
 <div class="card"><p>No dashboard modules are assigned to your role yet.</p></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/dashboard.blade.php ENDPATH**/ ?>