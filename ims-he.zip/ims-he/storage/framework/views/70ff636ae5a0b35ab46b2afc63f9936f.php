<?php $__env->startSection('title', 'Recent sales'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading"><h2>Recent sales</h2><a class="btn" href="<?php echo e(route('sales.create')); ?>">New sale</a></div>
 <table>
  <thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>Cashier</th><th>Total</th><th></th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr>
    <td>#<?php echo e($invoice->invoice_id); ?></td><td><?php echo e($invoice->invoice_date->format('M d, Y')); ?></td>
    <td><?php echo e($invoice->customer?->display_name ?: 'Walk-in customer'); ?></td>
    <td><?php echo e($invoice->employee?->full_name ?: 'System'); ?></td><td><?php echo e(money($invoice->total_amount)); ?></td>
    <td><a class="btn" href="<?php echo e(route('sales.show', $invoice)); ?>">Receipt</a></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="6">No in-store sales found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <?php echo e($invoices->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/sales/index.blade.php ENDPATH**/ ?>