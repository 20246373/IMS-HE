<?php $__env->startSection('title', 'Inventory report'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading">
  <h2>Inventory / stock summary</h2>
  <a class="btn no-print"
     href="<?php echo e(route('reports.inventory.download', array_filter(['category_id' => $categoryId]))); ?>">
   Save as PDF
  </a>
 </div>
 <form method="GET" action="<?php echo e(route('reports.inventory')); ?>" class="no-print report-filter">
  <label>Category
   <select name="category_id">
    <option value="">All categories</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($category->category_id); ?>"
       <?php if((int) $categoryId === (int) $category->category_id): echo 'selected'; endif; ?>>
      <?php echo e($category->category_name); ?>

     </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </label>
  <button type="submit">Apply filter</button>
 </form>
 <div class="report-summary">
  <div><strong>Total stock valuation</strong><span>&#8369;<?php echo e(number_format((float) $report['totalValuation'], 2)); ?></span></div>
  <div><strong>Low-stock alerts</strong><span><?php echo e(number_format($report['lowStockCount'])); ?></span></div>
 </div>
 <table>
  <thead><tr><th>Product</th><th>Category</th><th>Stock on hand</th><th>Reorder level</th><th>Unit price</th><th>Stock value</th><th>Status</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <?php ($isLowStock = $product->stock_quantity <= $product->reorder_level); ?>
   <tr>
    <td><?php echo e($product->product_name); ?></td>
    <td><?php echo e($product->category_name ?? 'Uncategorized'); ?></td>
    <td><?php echo e(number_format($product->stock_quantity)); ?></td>
    <td><?php echo e(number_format($product->reorder_level)); ?></td>
    <td>&#8369;<?php echo e(number_format((float) $product->unit_price, 2)); ?></td>
    <td>&#8369;<?php echo e(number_format((float) $product->stock_value, 2)); ?></td>
    <td class="<?php echo e($isLowStock ? 'low' : ''); ?>"><?php echo e($isLowStock ? 'Low stock' : 'In stock'); ?></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="7">No products found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\reports\inventory.blade.php ENDPATH**/ ?>