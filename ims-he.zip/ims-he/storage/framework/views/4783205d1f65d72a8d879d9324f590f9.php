<div class="grid">
 <div class="card"><div>User accounts</div><h2><?php echo e($accounts); ?></h2></div>
 <div class="card"><div>Waiting for a role</div><h2 class="<?php echo e($pendingAccounts ? 'low' : ''); ?>"><?php echo e($pendingAccounts); ?></h2><?php if($pendingAccounts): ?><a href="<?php echo e(route('users.index')); ?>">Review</a><?php endif; ?></div>
 <div class="card"><div>Locked accounts</div><h2 class="<?php echo e($locked ? 'low' : ''); ?>"><?php echo e($locked); ?></h2></div>
</div>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\dashboard\_accounts.blade.php ENDPATH**/ ?>