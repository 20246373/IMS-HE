
<div class="card product">
 <?php if($product->image_path): ?>
  <a class="product-media" href="<?php echo e(route('catalog.show', $product)); ?>">
   <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="<?php echo e($product->product_name); ?>">
  </a>
 <?php else: ?>
  <a class="product-media" href="<?php echo e(route('catalog.show', $product)); ?>">
   <div class="noimg">No image</div>
  </a>
 <?php endif; ?>
 <a class="product-name" href="<?php echo e(route('catalog.show', $product)); ?>">
  <strong><?php echo e($product->product_name); ?></strong>
 </a>
 <small><?php echo e($product->category->category_name); ?><?php if($product->brand): ?> &middot; <?php echo e($product->brand); ?><?php endif; ?></small>
 <div class="product-foot">
  <span class="price"><?php echo e(money($product->unit_price)); ?></span>
  <?php echo $__env->make('catalog._stock', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 </div>
 <?php if($product->isInStock()): ?>
  
  <form method="POST" action="<?php echo e(route('customer.cart.add', $product)); ?>"><?php echo csrf_field(); ?>
   <input type="hidden" name="quantity" value="1">
   <button class="product-add" type="submit">Add to Cart</button>
  </form>
 <?php endif; ?>
</div>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/catalog/_card.blade.php ENDPATH**/ ?>