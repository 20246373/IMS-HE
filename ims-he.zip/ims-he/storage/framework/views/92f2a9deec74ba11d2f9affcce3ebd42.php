
<a class="card product" href="<?php echo e(route('catalog.show', $product)); ?>">
 <?php if($product->image_path): ?>
  <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="<?php echo e($product->product_name); ?>">
 <?php else: ?>
  <div class="noimg">No image</div>
 <?php endif; ?>
 <small><?php echo e($product->category->category_name); ?></small>
 <strong><?php echo e($product->product_name); ?></strong>
 <div>&#8369;<?php echo e(number_format($product->unit_price, 2)); ?></div>
 <?php echo $__env->make('catalog._stock', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</a>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/catalog/_card.blade.php ENDPATH**/ ?>