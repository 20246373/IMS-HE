<?php $__env->startSection('title', 'Customer profile'); ?>
<?php $__env->startSection('heading', 'Customer Profile'); ?>
<?php $__env->startSection('page-actions'); ?>
 <a class="btn" href="<?php echo e(route('customers.edit', $customer)); ?>">Edit profile</a>
 <form method="POST" action="<?php echo e(route('customers.destroy', $customer)); ?>" class="inline"
       onsubmit="return confirm('Delete this customer account?')">
  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
  <button type="submit" class="danger">Delete account</button>
 </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="form-grid">
  <p><strong>Email</strong><br><?php echo e($customer->email); ?></p>
  <p><strong>Email status</strong><br><?php echo e($customer->hasVerifiedEmail() ? 'Verified' : 'Not verified'); ?></p>
  <p><strong>Name</strong><br><?php echo e(trim($customer->first_name.' '.$customer->last_name) ?: '—'); ?></p>
  <p><strong>Contact number</strong><br><?php echo e($customer->contact_number ?: '—'); ?></p>
  <p><strong>Address</strong><br><?php echo e($customer->address ?: '—'); ?></p>
 </div>
</div>
<div class="card">
 <h2>Orders</h2>
 <table>
  <thead><tr><th>Invoice</th><th>Date</th><th>Status</th><th>Total</th><th>Actions</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td>#<?php echo e($order->invoice_id); ?></td>
     <td><?php echo e($order->invoice_date->format('M d, Y')); ?></td>
     <td><?php echo $__env->make('orders._status', ['status' => $order->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
     <td><?php echo e(money($order->total_amount)); ?></td>
     <td><?php if($order->channel === 'Online'): ?><a href="<?php echo e(route('online-orders.show', $order)); ?>">Open online order</a><?php endif; ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="5">This customer has no orders.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/customers/show.blade.php ENDPATH**/ ?>