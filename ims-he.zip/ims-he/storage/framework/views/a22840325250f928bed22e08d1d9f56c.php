<?php $__env->startSection('title','My orders'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <h2>My orders</h2>
 <form method="GET" action="<?php echo e(route('customer.orders.index')); ?>" class="search">
  <select name="status" aria-label="Filter by status">
   <option value="">All statuses</option>
   <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s); ?>" <?php if($status === $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <button>Filter</button>
  <?php if($status): ?><a href="<?php echo e(route('customer.orders.index')); ?>">Clear</a><?php endif; ?>
 </form>

 <?php if($orders->isEmpty()): ?>
  <p><?php echo e($status ? "You have no {$status} orders." : 'You have not placed any orders yet.'); ?></p>
  <a class="btn" href="<?php echo e(route('catalog.index')); ?>">Browse products</a>
 <?php else: ?>
  <table class="cart-table">
   <tr><th>Order</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr>
   <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td>#<?php echo e($o->invoice_id); ?></td>
     <td><?php echo e($o->invoice_date->format('M d, Y')); ?></td>
     <td><?php echo e($o->items_count); ?></td>
     <td><?php echo e(money($o->total_amount)); ?></td>
     <td><?php echo e($o->payment?->payment_method); ?></td>
     <td><?php echo $__env->make('orders._status', ['status' => $o->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
     <td><a href="<?php echo e(route('customer.orders.show', $o)); ?>">View receipt</a></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php if($orders->hasPages()): ?>
   <p class="pager">
    <?php if($orders->onFirstPage()): ?><span>Previous</span><?php else: ?><a href="<?php echo e($orders->previousPageUrl()); ?>">Previous</a><?php endif; ?>
    <span>Page <?php echo e($orders->currentPage()); ?> of <?php echo e($orders->lastPage()); ?></span>
    <?php if($orders->hasMorePages()): ?><a href="<?php echo e($orders->nextPageUrl()); ?>">Next</a><?php else: ?><span>Next</span><?php endif; ?>
   </p>
  <?php endif; ?>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\orders\index.blade.php ENDPATH**/ ?>