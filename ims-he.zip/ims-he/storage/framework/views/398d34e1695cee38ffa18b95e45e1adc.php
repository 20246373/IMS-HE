<?php $__env->startSection('title','Receive delivery'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <h2>Receive delivery</h2>
 <form method="GET" action="<?php echo e(route('deliveries.create')); ?>">
  <label>Pending purchase order
   <select name="purchase_order_id" required>
    <option value="">Select a purchase order</option>
    <?php $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($purchaseOrder->po_id); ?>" <?php if(request('purchase_order_id') == $purchaseOrder->po_id): echo 'selected'; endif; ?>>
      PO #<?php echo e($purchaseOrder->po_id); ?> — <?php echo e($purchaseOrder->supplier->supplier_name); ?> (<?php echo e($purchaseOrder->order_date->format('M d, Y')); ?>)
     </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </label>
  <button>Load purchase order</button>
 </form>
 <?php if($purchaseOrders->isEmpty()): ?>
  <p>There are no pending purchase orders to receive.</p>
 <?php endif; ?>

 <?php if($selectedOrder): ?>
 <h3>PO #<?php echo e($selectedOrder->po_id); ?> — <?php echo e($selectedOrder->supplier->supplier_name); ?></h3>
 <form method="POST" action="<?php echo e(route('deliveries.store')); ?>" id="delivery-form">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="purchase_order_id" value="<?php echo e($selectedOrder->po_id); ?>">
  <table>
   <tr><th>Product</th><th>Ordered</th><th>Previously received</th><th>Remaining</th><th>Receive now</th></tr>
   <?php $__currentLoopData = $selectedOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <?php ($remaining = max(0, $item->quantity - $item->quantity_received)); ?>
   <tr>
    <td><?php echo e($item->product->product_name); ?></td>
    <td><?php echo e($item->quantity); ?></td>
    <td><?php echo e($item->quantity_received); ?></td>
    <td><?php echo e($remaining); ?></td>
    <td>
     <input type="hidden" name="items[<?php echo e($index); ?>][po_item_id]" value="<?php echo e($item->po_item_id); ?>">
     <input
      type="number"
      name="items[<?php echo e($index); ?>][quantity_received]"
      min="0"
      max="<?php echo e($remaining); ?>"
      step="1"
      value="<?php echo e(old('items.' . $index . '.quantity_received', 0)); ?>"
      data-remaining="<?php echo e($remaining); ?>"
      aria-describedby="delivery-error-<?php echo e($index); ?>"
      required
     >
     <small id="delivery-error-<?php echo e($index); ?>" class="low delivery-error" aria-live="polite"></small>
    </td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <p><button>Confirm delivery</button></p>
 </form>
 <script>
  (() => {
   const form = document.getElementById('delivery-form');
   const quantityInputs = form.querySelectorAll('input[name$="[quantity_received]"]');

   const validateQuantity = (input) => {
    const remaining = Number(input.dataset.remaining);
    const quantity = Number(input.value);
    const invalid = !Number.isInteger(quantity) || quantity < 0 || quantity > remaining;
    input.setCustomValidity(invalid ? `Enter a whole quantity from 0 to ${remaining}.` : '');
    input.closest('td').querySelector('.delivery-error').textContent = invalid
     ? `Cannot receive more than ${remaining} remaining.`
     : '';
    return !invalid;
   };

   quantityInputs.forEach((input) => input.addEventListener('input', () => validateQuantity(input)));
   form.addEventListener('submit', (event) => {
    if (![...quantityInputs].every(validateQuantity)) {
     event.preventDefault();
     form.reportValidity();
    }
   });
  })();
 </script>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\deliveries\create.blade.php ENDPATH**/ ?>