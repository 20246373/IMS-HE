<?php $__env->startSection('title','Accounts'); ?>
<?php $__env->startSection('content'); ?>
<?php if($pending->isNotEmpty()): ?>
<div class="card">
 <h3>Waiting for a role (<?php echo e($pending->count()); ?>)</h3>
 <p><small>These employees signed up themselves. Choose a role to give them access, or delete the account if you do not know them.</small></p>
 <table>
  <tr><th>Email</th><th>Signed up</th><th>Role</th><th>Employee record</th><th></th></tr>
  <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
   <td><?php echo e($p->label()); ?></td>
   <td><?php echo e($p->created_at?->format('M d, Y')); ?></td>
   <td>
    <select name="role" form="role-<?php echo e($p->user_id); ?>" required>
     <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r); ?>"><?php echo e($r); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   </td>
   <td>
    <select name="employee_id" form="role-<?php echo e($p->user_id); ?>">
     <option value="">-- none --</option>
     <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($e->employee_id); ?>"><?php echo e($e->full_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   </td>
   <td>
    <form id="role-<?php echo e($p->user_id); ?>" method="POST" action="<?php echo e(route('users.role', $p)); ?>" class="inline"><?php echo csrf_field(); ?><button>Approve</button></form>
    <form method="POST" action="<?php echo e(route('users.destroy', $p)); ?>" class="inline" onsubmit="return confirm('Delete this account?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="danger">Delete</button></form>
   </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </table>
</div>
<?php endif; ?>

<div class="card">
 <table>
  <tr><th>Account</th><th>Employee</th><th>Role</th><th>Status</th><th>Last login</th><th></th></tr>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
   <td><?php echo e($u->label()); ?><?php if($u->username && $u->email): ?><br><small><?php echo e($u->email); ?></small><?php endif; ?></td>
   <td><?php echo e($u->employee?->full_name ?? '-'); ?></td>
   <td><?php echo e($u->role); ?></td>
   <td class="<?php echo e($u->isLocked() ? 'low' : ''); ?>"><?php echo e($u->status); ?></td>
   <td><?php echo e($u->last_login?->format('M d, Y H:i') ?? 'never'); ?></td>
   <td>
    <a class="btn" href="<?php echo e(route('users.edit', $u)); ?>">Edit</a>
    <?php if($u->isLocked()): ?>
     <form method="POST" action="<?php echo e(route('users.unlock', $u)); ?>" class="inline"><?php echo csrf_field(); ?><button>Unlock</button></form>
    <?php elseif(!$u->is(auth()->user())): ?>
     <form method="POST" action="<?php echo e(route('users.lock', $u)); ?>" class="inline"><?php echo csrf_field(); ?><button class="danger">Lock</button></form>
    <?php endif; ?>
    <?php if(!$u->is(auth()->user())): ?>
     <form method="POST" action="<?php echo e(route('users.destroy', $u)); ?>" class="inline" onsubmit="return confirm('Delete this account?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="danger">Delete</button></form>
    <?php endif; ?>
   </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/users/index.blade.php ENDPATH**/ ?>