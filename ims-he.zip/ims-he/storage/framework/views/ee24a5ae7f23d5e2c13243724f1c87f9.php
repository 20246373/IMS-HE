<?php $__env->startSection('title', 'Payslip'); ?>
<?php $__env->startPush('head'); ?>
<style>@media print{nav, .no-print{display:none!important}body.staff-layout main{width:auto;margin:0;padding:0}.card{box-shadow:none}}</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading no-print"><h2>Payslip</h2><button onclick="window.print()">Print</button></div>
 <h2><?php echo e($payslip->employee->full_name); ?></h2>
 <p>Payroll period: <?php echo e($payroll->period_start->format('M d, Y')); ?> – <?php echo e($payroll->period_end->format('M d, Y')); ?></p>
 <table>
  <tr><th>Days worked</th><td><?php echo e(number_format((float) $payslip->days_worked, 2)); ?></td></tr>
  <tr><th>Overtime hours</th><td><?php echo e(number_format((float) $payslip->overtime_hours, 2)); ?></td></tr>
  <tr><th>Gross pay</th><td><?php echo e(money($payslip->gross_pay)); ?></td></tr>
  <tr><th>SSS</th><td><?php echo e(money($payslip->sss_deduction)); ?></td></tr>
  <tr><th>PhilHealth</th><td><?php echo e(money($payslip->philhealth_deduction)); ?></td></tr>
  <tr><th>Pag-IBIG</th><td><?php echo e(money($payslip->pagibig_deduction)); ?></td></tr>
  <tr><th>Withholding tax</th><td><?php echo e(money($payslip->tax_deduction)); ?></td></tr>
  <tr><th>Total deductions</th><td><?php echo e(money($payslip->total_deductions)); ?></td></tr>
  <tr><th>Net pay</th><td><?php echo e(money($payslip->net_pay)); ?></td></tr>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\payroll\payslip.blade.php ENDPATH**/ ?>