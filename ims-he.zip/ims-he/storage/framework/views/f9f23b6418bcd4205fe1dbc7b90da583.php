<?php $__env->startSection('title', 'Payroll'); ?>
<?php $__env->startSection('heading', 'Payroll'); ?>
<?php $__env->startSection('page-actions'); ?><a class="btn" href="<?php echo e(route('payrolls.create')); ?>">Run payroll</a><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <table>
  <thead><tr><th>Period</th><th>Status</th><th>Gross</th><th>Deductions</th><th>Net</th><th>Actions</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td><?php echo e($payroll->period_start->format('M d, Y')); ?> – <?php echo e($payroll->period_end->format('M d, Y')); ?></td>
     <td><?php echo e($payroll->status); ?></td>
     <td><?php echo e(money($payroll->total_gross)); ?></td>
     <td><?php echo e(money($payroll->total_deductions)); ?></td>
     <td><?php echo e(money($payroll->total_net)); ?></td>
     <td><a class="btn" href="<?php echo e(route('payrolls.show', $payroll)); ?>">Open</a></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="6">No payrolls found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <?php echo e($payrolls->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/payroll/index.blade.php ENDPATH**/ ?>