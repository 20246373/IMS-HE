<?php $__env->startSection('title','Edit account'); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:480px">
 <h3>Edit <?php echo e($user->label()); ?></h3>
 <form method="POST" action="<?php echo e(route('users.update', $user)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
  <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
  <?php echo $__env->make('users._fields', ['kit' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <p><button>Save</button> <a class="btn danger" href="<?php echo e(route('users.index')); ?>">Cancel</a></p>
 </form>
</div>
<div class="card" style="max-width:480px">
 <h3>Reset password</h3>
 <form method="POST" action="<?php echo e(route('users.password', $user)); ?>"><?php echo csrf_field(); ?>
  <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
  <div class="form-grid">
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'New password (min 8)','name' => 'password','type' => 'password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'New password (min 8)','name' => 'password','type' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Confirm password','name' => 'password_confirmation','type' => 'password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Confirm password','name' => 'password_confirmation','type' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
  </div>
  <p><button>Reset password</button></p>
 </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/users/edit.blade.php ENDPATH**/ ?>