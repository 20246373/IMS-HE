<?php $__env->startSection('title','Edit category'); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:420px"><h3>Edit category</h3>
 <form method="POST" action="<?php echo e(route('categories.update', $category)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
  <label>Name <input name="category_name" value="<?php echo e(old('category_name', $category->category_name)); ?>" maxlength="50" required></label>
  <p><button>Save</button> <a class="btn" href="<?php echo e(route('categories.index')); ?>">Cancel</a></p>
 </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\categories\edit.blade.php ENDPATH**/ ?>