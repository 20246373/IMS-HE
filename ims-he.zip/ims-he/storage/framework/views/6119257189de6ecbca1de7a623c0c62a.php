<?php $__env->startSection('title','Products'); ?>
<?php $__env->startSection('heading', 'Products'); ?>
<?php $__env->startSection('page-actions'); ?><a class="btn" href="<?php echo e(route('products.create')); ?>">+ Add product</a><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <form method="GET" class="report-filter">
  <label>Search <input name="q" placeholder="Name or brand" value="<?php echo e(request('q')); ?>"></label>
  <label>Category
  <select name="category"><option value="">All categories</option>
   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->category_id); ?>" <?php if((string) request('category') === (string) $c->category_id): echo 'selected'; endif; ?>><?php echo e($c->category_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  </label>
  <button>Filter</button>
 </form>
 <table>
  <tr><th>Photo</th><th>Name</th><th>Brand</th><th>Category</th><th>Price</th><th>Stock</th><th>Reorder</th><th>Actions</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
   <td><?php if($p->image_path): ?><img src="<?php echo e(asset('storage/' . $p->image_path)); ?>" alt="" style="height:36px;width:36px;object-fit:cover;border-radius:4px"><?php endif; ?></td>
   <td><?php echo e($p->product_name); ?></td>
   <td><?php echo e($p->brand); ?></td>
   <td><?php echo e($p->category?->category_name); ?></td>
   <td><?php echo e(money($p->unit_price)); ?></td>
   <td class="<?php echo e($p->isLowStock() ? 'low' : ''); ?>"><?php echo e($p->stock_quantity); ?></td>
   <td><?php echo e($p->reorder_level); ?></td>
   <td>
    <a class="btn" href="<?php echo e(route('products.stock-history', $p)); ?>">Stock history</a>
    <a class="btn" href="<?php echo e(route('products.edit', $p)); ?>">Edit</a>
    <form method="POST" action="<?php echo e(route('products.destroy', $p)); ?>" class="inline" onsubmit="return confirm('Are you sure you want to delete this record? This action cannot be undone.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="danger">Delete</button></form>
   </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="8">No products found.</td></tr>
  <?php endif; ?>
 </table>
 <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/products/index.blade.php ENDPATH**/ ?>