<?php $__env->startSection('title', 'Financial report'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading"><h2>Financial report</h2><a class="btn" href="<?php echo e(route('reports.financial.download', ['start_date' => $startDate, 'end_date' => $endDate])); ?>">Save as PDF</a></div>
 <form method="GET" action="<?php echo e(route('reports.financial')); ?>" class="report-filter">
  <label>From <input type="date" name="start_date" value="<?php echo e($startDate); ?>" required></label>
  <label>To <input type="date" name="end_date" value="<?php echo e($endDate); ?>" required></label>
  <button type="submit">Apply filter</button>
 </form>
 <div class="report-summary"><div><strong>Income</strong><span><?php echo e(money($report['totalIncome'])); ?></span></div><div><strong>Expense</strong><span><?php echo e(money($report['totalExpense'])); ?></span></div><div><strong>Net</strong><span><?php echo e(money($report['totalNet'])); ?></span></div></div>
 <table><thead><tr><th>Date</th><th>Income</th><th>Expense</th><th>Net</th></tr></thead><tbody>
 <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e(\Illuminate\Support\Carbon::parse($day['date'])->format('M d, Y')); ?></td><td><?php echo e(money($day['income'])); ?></td><td><?php echo e(money($day['expense'])); ?></td><td><?php echo e(money($day['net'])); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody></table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\reports\financial.blade.php ENDPATH**/ ?>