<?php $__env->startSection('title','My cart'); ?>
<?php $__env->startSection('heading', 'My Cart'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <?php if($warnings): ?>
  <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'warning','title' => 'Your cart was updated']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning','title' => 'Your cart was updated']); ?>
   <ul><?php $__currentLoopData = $warnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($w); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
 <?php endif; ?>
 <?php if($items->isEmpty()): ?>
  <p>Your cart is empty.</p>
  <a class="btn" href="<?php echo e(route('catalog.index')); ?>">Browse products</a>
 <?php else: ?>
  <table class="cart-table">
   <tr><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th></th></tr>
   <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($p = $item->product); ?>
    <tr data-price="<?php echo e($p->unit_price); ?>">
     <td>
      <a href="<?php echo e(route('catalog.show', $p)); ?>"><?php echo e($p->product_name); ?></a>
      <div class="low line-error" hidden></div>
     </td>
     <td><?php echo e(money($p->unit_price)); ?></td>
     <td>
      
      <form method="POST" action="<?php echo e(route('customer.cart.update', $item)); ?>" class="qty cart-qty" data-saved="<?php echo e($item->quantity); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
       <?php echo $__env->make('partials.qty', ['value' => $item->quantity, 'max' => max(1, $p->stock_quantity)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </form>
     </td>
     <td class="line-subtotal"><?php echo e(money($item->quantity * $p->unit_price)); ?></td>
     <td>
      <form method="POST" action="<?php echo e(route('customer.cart.remove', $item)); ?>" class="inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
       <button class="danger">Remove</button>
      </form>
     </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <tr class="cart-total-row"><th colspan="3">Total</th><th id="cart-total"><?php echo e(money($total)); ?></th><th></th></tr>
  </table>
  <p>
   <a class="btn" href="<?php echo e(route('customer.checkout.show')); ?>">Checkout</a>
   <a href="<?php echo e(route('catalog.index')); ?>">Continue shopping</a>
  </p>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
 // Cart auto-update: recalculates subtotal/total on the page right away, then saves in the background.
 // The server re-checks stock; if it refuses, the quantity goes back to the last saved value.
 (function () {
  var peso = function (n) { return '\u20B1' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };

  function recalc() {
   var total = 0;
   document.querySelectorAll('tr[data-price]').forEach(function (row) {
    var qty = Number(row.querySelector('.cart-qty input[name=quantity]').value) || 0;
    var sub = qty * Number(row.dataset.price);
    row.querySelector('.line-subtotal').textContent = peso(sub);
    total += sub;
   });
   document.getElementById('cart-total').textContent = peso(total);
  }

  function reject(form, message) {
   var error = form.closest('tr').querySelector('.line-error');
   form.querySelector('input[name=quantity]').value = form.dataset.saved;
   error.textContent = message;
   error.hidden = false;
   recalc();
  }

  function save(form) {
   var row = form.closest('tr'), input = form.querySelector('input[name=quantity]'), error = row.querySelector('.line-error');

   // Typed values outside 1..stock are refused here, the same way the server would refuse them.
   if (input.validity.rangeOverflow) return reject(form, 'Only ' + input.max + ' in stock.');
   if (!input.checkValidity()) return reject(form, 'Enter a quantity of at least 1.');

   fetch(form.action, {
    method: 'POST',                                   // _method=PATCH travels in the form data
    body: new FormData(form),
    headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
   }).then(function (res) {
    return res.json().then(function (data) { return { ok: res.ok, data: data }; });
   }).then(function (r) {
    if (!r.ok) throw new Error(r.data.errors && r.data.errors.quantity ? r.data.errors.quantity[0] : (r.data.message || 'Could not update the cart.'));
    form.dataset.saved = r.data.quantity;
    error.hidden = true;
    row.querySelector('.line-subtotal').textContent = peso(r.data.subtotal);
    document.getElementById('cart-total').textContent = peso(r.data.total);
    var count = document.getElementById('cart-count');
    if (count) count.textContent = r.data.count;
   }).catch(function (e) { reject(form, e.message); });
  }

  var timers = new WeakMap();
  document.querySelectorAll('.cart-qty').forEach(function (form) {
   form.addEventListener('submit', function (e) { e.preventDefault(); save(form); });   // Enter key
   form.querySelector('input[name=quantity]').addEventListener('input', function () {
    recalc();
    clearTimeout(timers.get(form));
    timers.set(form, setTimeout(function () { save(form); }, 400));   // wait for fast clicks / typing
   });
  });
 })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/cart/index.blade.php ENDPATH**/ ?>