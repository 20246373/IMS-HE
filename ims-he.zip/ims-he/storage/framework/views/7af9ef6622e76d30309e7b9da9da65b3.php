<?php $__env->startSection('title','Receipt #'.$invoice->invoice_id); ?>
<?php $__env->startSection('content'); ?>
<div class="card" id="receipt" style="max-width:640px">
 <h2>Receipt &mdash; Order #<?php echo e($invoice->invoice_id); ?></h2>
 <p>
  <strong>Ibay Enterprises Corporation</strong><br>
  Date: <?php echo e($invoice->invoice_date->format('M d, Y')); ?><br>
  Status: <?php echo $__env->make('orders._status', ['status' => $invoice->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 </p>
 <p>
  <strong>Deliver to</strong><br>
  <?php echo e(trim($invoice->customer->first_name.' '.$invoice->customer->last_name)); ?><br>
  <?php echo e($invoice->customer->contact_number); ?><br>
  <?php echo e($invoice->customer->address); ?>

 </p>

 <table class="cart-table">
  <tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr>
  <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($line->product->product_name); ?></td>
    <td><?php echo e(money($line->price)); ?></td>
    <td><?php echo e($line->quantity); ?></td>
    <td><?php echo e(money($line->subtotal)); ?></td>
   </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tr class="cart-total-row"><th colspan="3">Total</th><th><?php echo e(money($invoice->total_amount)); ?></th></tr>
 </table>

 <p>Payment method: <strong><?php echo e($invoice->payment?->payment_method); ?></strong></p>
 <?php if($invoice->status === 'Cancelled'): ?>
  <p><strong>This order was cancelled.</strong> No payment is due.</p>
 <?php else: ?>
  <p><small>Thank you for your order. The store will contact you to arrange payment and pickup or delivery.</small></p>
 <?php endif; ?>

 <p class="no-print">
  <button type="button" onclick="window.print()">Print receipt</button>
  <a class="btn" href="<?php echo e(route('customer.orders.index')); ?>">My orders</a>
  <a class="btn btn-alt" href="<?php echo e(route('catalog.index')); ?>">Continue shopping</a>
 </p>
</div>
<?php $__env->startPush('head'); ?>
<style>@media print { nav, .no-print, [role=alert] { display: none !important; } body { background: #fff; } main { margin: 0 !important; } #receipt { box-shadow: none; max-width: none !important; } .status { border: 1px solid currentColor; } }</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\orders\show.blade.php ENDPATH**/ ?>