<p>Hello,</p>
<p>We received a request to reset your Ibay Enterprises password.</p>
<p><a href="<?php echo e($url); ?>">Reset my password</a></p>
<p>If the button does not work, copy this link into your browser:<br><?php echo e($url); ?></p>
<p>This link expires in 60 minutes and stops working after your password changes. If you did not request this, you can ignore this email.</p>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\emails\reset-password.blade.php ENDPATH**/ ?>