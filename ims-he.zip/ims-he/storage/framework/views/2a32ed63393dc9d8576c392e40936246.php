<?php $__env->startSection('title','Stock monitoring'); ?>
<?php $__env->startPush('head'); ?>
<style>
 .lowrow td{background:#fff1d6}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="row" style="justify-content:space-between">
  <h3 style="margin:0">Stock monitoring</h3>
  <div>
   <a class="btn <?php echo e(request()->boolean('low') ? 'muted' : ''); ?>" href="<?php echo e(route('stock.index')); ?>">All</a>
   <a class="btn <?php echo e(request()->boolean('low') ? '' : 'muted'); ?>" href="<?php echo e(route('stock.index',['low'=>1])); ?>">Low stock only</a>
  </div>
 </div>
 <table>
  <tr><th>Product</th><th>Category</th><th>Stock quantity</th><th>Reorder level</th><th>Status</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr class="<?php echo e($p->isLowStock() ? 'lowrow' : ''); ?>">
   <td><?php echo e($p->product_name); ?></td><td><?php echo e($p->category?->category_name); ?></td>
   <td class="<?php echo e($p->isLowStock() ? 'low' : ''); ?>"><?php echo e($p->stock_quantity); ?></td><td><?php echo e($p->reorder_level); ?></td>
   <td><?php if($p->stock_quantity === 0): ?><span class="badge red">Out of stock</span><?php elseif($p->isLowStock()): ?><span class="badge amber">Reorder</span><?php else: ?><span class="badge green">OK</span><?php endif; ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="5">Nothing to show.</td></tr> <?php endif; ?>
 </table>
</div>
<div class="card"><h3>Recent stock movements</h3>
 <table>
  <tr><th>Date</th><th>Product</th><th>Type</th><th>Qty</th><th>Reference</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr><td><?php echo e($t->transaction_date->format('M d, Y')); ?></td><td><?php echo e($t->product->product_name); ?></td>
   <td><span class="badge <?php echo e($t->transaction_type==='IN' ? 'green' : 'amber'); ?>"><?php echo e($t->transaction_type); ?></span></td><td><?php echo e($t->quantity); ?></td>
   <td><?php echo e($t->reference_type); ?><?php echo e($t->reference_id ? ' #'.$t->reference_id : ''); ?></td></tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="5">No movements yet.</td></tr> <?php endif; ?>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\stock\index.blade.php ENDPATH**/ ?>