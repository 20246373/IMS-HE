
<?php if(! $product->isInStock()): ?><span class="stock out">Out of stock</span>
<?php elseif($product->isLowStock()): ?><span class="stock low">Low stock</span>
<?php else: ?><span class="stock in">In stock</span><?php endif; ?>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\catalog\_stock.blade.php ENDPATH**/ ?>