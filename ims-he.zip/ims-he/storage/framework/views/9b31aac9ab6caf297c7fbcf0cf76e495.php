<p>Hello <?php echo e($customer->display_name); ?>,</p>
<p>Thanks for signing up with Ibay Enterprises. Please confirm your email address to activate your account:</p>
<p><a href="<?php echo e($url); ?>">Verify my email</a></p>
<p>If the button does not work, copy this link into your browser:<br><?php echo e($url); ?></p>
<p>This link expires in 24 hours. If you did not sign up, you can ignore this email.</p>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\emails\verify-email.blade.php ENDPATH**/ ?>