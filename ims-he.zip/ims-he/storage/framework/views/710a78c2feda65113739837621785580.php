<?php $__env->startSection('title', 'Stock history - ' . $product->product_name); ?>
<?php $__env->startPush('head'); ?>
<style>
 .badge{display:inline-block;padding:.12rem .5rem;border-radius:999px;background:#eef0f3;color:#333;font-size:.72rem;font-weight:700;line-height:1.2;vertical-align:middle}
 .badge.green{background:#e8f7ed;color:#176b35}
 .badge.amber{background:#fff5d8;color:#785b00}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;flex-wrap:wrap">
  <div>
   <h2 style="margin:0">Stock history: <?php echo e($product->product_name); ?></h2>
   <p style="margin:.35rem 0 0">
    Current stock: <strong><?php echo e($product->stock_quantity); ?></strong>
    &middot; Reorder level: <strong><?php echo e($product->reorder_level); ?></strong>
   </p>
  </div>
  <a class="btn" href="<?php echo e(route('products.index')); ?>">Back to products</a>
 </div>

 <table style="margin-top:1rem">
  <tr>
   <th>Date</th>
   <th>Type</th>
   <th>Quantity</th>
   <th>Reference type</th>
   <th>Reference ID</th>
   <th>Resulting stock</th>
  </tr>
  <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
   <td><?php echo e($transaction->transaction_date->format('M d, Y')); ?></td>
   <td><span class="badge <?php echo e($transaction->transaction_type === 'IN' ? 'green' : 'amber'); ?>"><?php echo e($transaction->transaction_type); ?></span></td>
   <td><?php echo e($transaction->quantity); ?></td>
   <td><?php echo e($transaction->reference_type); ?></td>
   <td><?php echo e($transaction->reference_id); ?></td>
   <td><?php echo e($transaction->resulting_stock ?? '—'); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="6">No stock movements recorded for this product.</td></tr>
  <?php endif; ?>
 </table>

 <?php echo e($transactions->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\products\stock-history.blade.php ENDPATH**/ ?>