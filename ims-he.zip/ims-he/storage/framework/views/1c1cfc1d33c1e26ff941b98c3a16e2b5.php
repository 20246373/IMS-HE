<?php $__env->startSection('title','New purchase order'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <h2>New purchase order</h2>
 <?php if($suppliers->isEmpty() || $products->isEmpty()): ?>
  <p>A supplier and at least one product are required before creating a purchase order.</p>
 <?php else: ?>
 <form method="POST" action="<?php echo e(route('purchase-orders.store')); ?>" id="purchase-order-form">
  <?php echo csrf_field(); ?>
  <label>Supplier
   <select name="supplier_id" required>
    <option value="">Select a supplier</option>
    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($supplier->supplier_id); ?>" <?php if(old('supplier_id') == $supplier->supplier_id): echo 'selected'; endif; ?>><?php echo e($supplier->supplier_name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </label>
  <h3>Products</h3>
  <table>
   <thead><tr><th>Product</th><th>Quantity</th><th>Unit cost</th><th>Subtotal</th><th></th></tr></thead>
   <tbody id="purchase-order-lines">
    <?php ($oldItems = old('items')); ?>
    <?php if(!is_array($oldItems) || $oldItems === []): ?>
     <?php ($oldItems = [['product_id' => '', 'quantity' => 1, 'unit_cost' => '0.00']]); ?>
    <?php endif; ?>
    <?php ($lineIndex = 0); ?>
    <?php $__currentLoopData = $oldItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($line = is_array($line) ? $line : []); ?>
    <tr class="purchase-order-line">
     <td>
      <select name="items[<?php echo e($lineIndex); ?>][product_id]" required>
       <option value="">Select a product</option>
       <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($product->product_id); ?>" <?php if(($line['product_id'] ?? '') == $product->product_id): echo 'selected'; endif; ?>><?php echo e($product->product_name); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
     </td>
     <td><input type="number" name="items[<?php echo e($lineIndex); ?>][quantity]" min="1" step="1" value="<?php echo e($line['quantity'] ?? 1); ?>" required></td>
     <td><div class="input-with-prefix"><span>₱</span><input type="number" name="items[<?php echo e($lineIndex); ?>][unit_cost]" min="0" max="99999999.99" step="0.01" value="<?php echo e($line['unit_cost'] ?? '0.00'); ?>" required></div></td>
     <td class="line-subtotal"><?php echo e(money(0)); ?></td>
     <td><button type="button" class="danger remove-line">Remove</button></td>
    </tr>
    <?php ($lineIndex++); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
  </table>
  <p><button type="button" id="add-line">Add product line</button></p>
  <p><strong>PO total: <span id="purchase-order-total"><?php echo e(money(0)); ?></span></strong></p>
  <button>Create purchase order</button>
  <a class="btn" href="<?php echo e(route('purchase-orders.index')); ?>">Cancel</a>
 </form>
 <template id="purchase-order-line-template">
  <tr class="purchase-order-line">
   <td>
    <select required>
     <option value="">Select a product</option>
     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($product->product_id); ?>"><?php echo e($product->product_name); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   </td>
   <td><input type="number" min="1" step="1" value="1" required></td>
   <td><div class="input-with-prefix"><span>₱</span><input type="number" min="0" max="99999999.99" step="0.01" value="0.00" required></div></td>
   <td class="line-subtotal"><?php echo e(money(0)); ?></td>
   <td><button type="button" class="danger remove-line">Remove</button></td>
  </tr>
 </template>
 <script>
  (() => {
   const lines = document.getElementById('purchase-order-lines');
   const template = document.getElementById('purchase-order-line-template');
   let nextIndex = <?php echo e($lineIndex); ?>;

   const updateTotals = () => {
    let total = 0;
    lines.querySelectorAll('.purchase-order-line').forEach((line) => {
     const quantity = Number(line.querySelector('[name$="[quantity]"]').value) || 0;
     const unitCost = Number(line.querySelector('[name$="[unit_cost]"]').value) || 0;
     const subtotal = quantity * unitCost;
     total += subtotal;
     line.querySelector('.line-subtotal').textContent = '₱' + subtotal.toFixed(2);
    });
    document.getElementById('purchase-order-total').textContent = '₱' + total.toFixed(2);
   };

   document.getElementById('add-line').addEventListener('click', () => {
    const row = template.content.firstElementChild.cloneNode(true);
    row.querySelector('select').name = `items[${nextIndex}][product_id]`;
    row.querySelectorAll('input')[0].name = `items[${nextIndex}][quantity]`;
    row.querySelectorAll('input')[1].name = `items[${nextIndex}][unit_cost]`;
    nextIndex += 1;
    lines.appendChild(row);
    updateTotals();
   });

   lines.addEventListener('input', updateTotals);
   lines.addEventListener('click', (event) => {
    if (event.target.matches('.remove-line')) {
     if (lines.querySelectorAll('.purchase-order-line').length > 1) {
      event.target.closest('.purchase-order-line').remove();
      updateTotals();
     }
    }
   });

   updateTotals();
  })();
 </script>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/purchase-orders/create.blade.php ENDPATH**/ ?>