<?php $__env->startSection('title', 'Purchase Order #' . $purchaseOrder->po_id); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <h2>Purchase Order #<?php echo e($purchaseOrder->po_id); ?></h2>
 <p>Supplier: <strong><?php echo e($purchaseOrder->supplier->supplier_name); ?></strong></p>
 <p>Order date: <?php echo e($purchaseOrder->order_date->format('M d, Y')); ?></p>
 <p>Status: <strong><?php echo e($purchaseOrder->status); ?></strong></p>
 <?php if($purchaseOrder->status === 'Pending'): ?>
  <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;margin:1rem 0">
   <a class="btn" href="<?php echo e(route('deliveries.create', ['purchase_order_id' => $purchaseOrder->po_id])); ?>">Record delivery</a>
   <form method="POST" action="<?php echo e(route('purchase-orders.cancel', $purchaseOrder)); ?>" class="inline" onsubmit="return confirm('Cancel this purchase order?')">
    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
    <button class="danger">Cancel purchase order</button>
   </form>
  </div>
 <?php endif; ?>
 <table>
  <tr><th>Product</th><th>Ordered</th><th>Received</th><th>Remaining</th><th>Unit cost</th><th>Subtotal</th></tr>
  <?php $__currentLoopData = $purchaseOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
   <td><?php echo e($item->product->product_name); ?></td>
   <td><?php echo e($item->quantity); ?></td>
   <td><?php echo e($item->quantity_received); ?></td>
   <td><?php echo e(max(0, $item->quantity - $item->quantity_received)); ?></td>
   <td><?php echo e(money($item->unit_cost)); ?></td>
   <td><?php echo e(money($item->subtotal)); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tr><th colspan="5" style="text-align:right">Total</th><th><?php echo e(money($purchaseOrder->items->sum('subtotal'))); ?></th></tr>
 </table>
 <p><a class="btn" href="<?php echo e(route('purchase-orders.index')); ?>">Back to purchase orders</a></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\purchase-orders\show.blade.php ENDPATH**/ ?>