<?php $__env->startSection('title','Categories'); ?>
<?php $__env->startSection('heading', 'Categories'); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><h3>Add category</h3>
 <form method="POST" action="<?php echo e(route('categories.store')); ?>"><?php echo csrf_field(); ?>
  <input name="category_name" placeholder="Category name" value="<?php echo e(old('category_name')); ?>" maxlength="50" required> <button>Add</button>
 </form>
</div>
<div class="card">
 <table>
  <tr><th>Name</th><th>Products</th><th>Actions</th></tr>
  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
   <td><?php echo e($c->category_name); ?></td><td><?php echo e($c->products_count); ?></td>
   <td>
    <a class="btn" href="<?php echo e(route('categories.edit', $c)); ?>">Edit</a>
    <form method="POST" action="<?php echo e(route('categories.destroy', $c)); ?>" class="inline" onsubmit="return confirm('Are you sure you want to delete this record? This action cannot be undone.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="danger">Delete</button></form>
   </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/categories/index.blade.php ENDPATH**/ ?>