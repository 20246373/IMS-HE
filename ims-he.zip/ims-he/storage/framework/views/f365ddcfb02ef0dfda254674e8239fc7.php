<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading"><h2>Customers</h2></div>
 <form method="GET" action="<?php echo e(route('customers.index')); ?>" class="report-filter">
  <label>Search email or name <input type="search" name="q" value="<?php echo e($search); ?>" placeholder="Email or name"></label>
  <button type="submit">Search</button>
  <?php if($search !== ''): ?><a class="btn btn-alt" href="<?php echo e(route('customers.index')); ?>">Clear</a><?php endif; ?>
 </form>
 <table>
  <thead><tr><th>Email</th><th>Name</th><th>Contact number</th><th>Orders</th><th>Email status</th><th></th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td><?php echo e($customer->email); ?></td>
     <td><?php echo e(trim($customer->first_name.' '.$customer->last_name) ?: '—'); ?></td>
     <td><?php echo e($customer->contact_number ?: '—'); ?></td>
     <td><?php echo e($customer->invoices_count); ?></td>
     <td><?php echo e($customer->hasVerifiedEmail() ? 'Verified' : 'Not verified'); ?></td>
     <td><a class="btn" href="<?php echo e(route('customers.show', $customer)); ?>">View</a></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="6">No customers found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <?php echo e($customers->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\customers\index.blade.php ENDPATH**/ ?>