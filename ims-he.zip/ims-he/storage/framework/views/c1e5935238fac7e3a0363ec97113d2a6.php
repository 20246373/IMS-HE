<?php $__env->startSection('title', 'My attendance'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <h2>My attendance</h2>
 <?php if(!$employee): ?>
  <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'warning','title' => 'Employee record not linked']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning','title' => 'Employee record not linked']); ?>Your account has no employee record linked yet. Ask an Administrator to link it. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
 <?php else: ?>
  <p><strong><?php echo e($employee->full_name); ?></strong> · <?php echo e(today()->format('M d, Y')); ?></p>
  <table>
   <tr><th>Clock in</th><th>Clock out</th><th>Overtime</th><th></th></tr>
   <tr>
    <td><?php echo e($record?->time_in ?: '—'); ?></td>
    <td><?php echo e($record?->time_out ?: '—'); ?></td>
    <td><?php echo e(number_format((float) ($record?->overtime_hours ?? 0), 2)); ?> hours</td>
    <td>
     <?php if(!$record): ?>
      <form method="POST" action="<?php echo e(route('attendance.clock-in')); ?>" class="inline"><?php echo csrf_field(); ?><button>Clock in</button></form>
     <?php elseif(!$record->time_out): ?>
      <form method="POST" action="<?php echo e(route('attendance.clock-out')); ?>" class="inline"><?php echo csrf_field(); ?><button>Clock out</button></form>
     <?php else: ?>
      Complete
     <?php endif; ?>
    </td>
   </tr>
  </table>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/attendance/my.blade.php ENDPATH**/ ?>