<?php $__env->startSection('title', $product->product_name); ?>
<?php $__env->startSection('heading'); ?><?php echo e($product->product_name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card detail">
 <?php if($product->image_path): ?>
  <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="<?php echo e($product->product_name); ?>">
 <?php else: ?>
  <div class="noimg">No image</div>
 <?php endif; ?>
 <div>
  <small><a href="<?php echo e(route('catalog.index', ['category' => $product->category_id])); ?>"><?php echo e($product->category->category_name); ?></a></small>
  <?php if($product->brand): ?><p class="brand">Brand: <a href="<?php echo e(route('catalog.index', ['brand' => $product->brand])); ?>"><?php echo e($product->brand); ?></a></p><?php endif; ?>
  <p class="price"><?php echo e(money($product->unit_price)); ?></p>
  <p><?php echo $__env->make('catalog._stock', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></p>
  <?php if($product->description): ?><p><?php echo e($product->description); ?></p><?php endif; ?>
  
  <?php if($product->isInStock()): ?>
   <form method="POST" action="<?php echo e(route('customer.cart.add', $product)); ?>" class="qty" data-cart-add><?php echo csrf_field(); ?>
    <label>Quantity</label> <?php echo $__env->make('partials.qty', ['value' => 1, 'max' => $product->stock_quantity], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <button>Add to cart</button>
    <p class="cart-add-error" hidden></p>
   </form>
  <?php endif; ?>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/catalog/show.blade.php ENDPATH**/ ?>