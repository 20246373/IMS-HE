<?php $__env->startSection('title','My account'); ?>
<?php $__env->startSection('heading', 'My Account'); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:560px">
 <table>
  <tr><th>Email</th><td><?php echo e($customer->email); ?></td></tr>
  <tr><th>Member since</th><td><?php echo e($customer->created_at?->format('M j, Y')); ?></td></tr>
 </table>
</div>

<div class="card" style="max-width:560px">
 <h3>My profile</h3>
 <p><small>Optional for now. You will need an address and a contact number when you check out.</small></p>
 <form method="POST" action="<?php echo e(route('customer.account.update')); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
  <label>First name <input name="first_name" value="<?php echo e(old('first_name', $customer->first_name)); ?>" maxlength="50"></label>
  <label>Last name <input name="last_name" value="<?php echo e(old('last_name', $customer->last_name)); ?>" maxlength="50"></label>
  <label>Contact number <input name="contact_number" value="<?php echo e(old('contact_number', $customer->contact_number)); ?>" maxlength="14" inputmode="numeric" pattern="[0-9]*" title="Digits only"></label>
  <label>Address <input name="address" value="<?php echo e(old('address', $customer->address)); ?>" maxlength="100"></label>
  <p><button>Save profile</button></p>
 </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/customer/account.blade.php ENDPATH**/ ?>