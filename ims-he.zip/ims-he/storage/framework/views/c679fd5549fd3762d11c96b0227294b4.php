<?php $__env->startSection('title', 'Sales POS'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <h2>Sales (POS)</h2>
 <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
 <form method="GET" action="<?php echo e(route('sales.create')); ?>" class="report-filter no-print">
  <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Search product','name' => 'q','value' => $filters['q'] ?? null,'required' => false,'placeholder' => 'Name or brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Search product','name' => 'q','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['q'] ?? null),'required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'placeholder' => 'Name or brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['label' => 'Category','name' => 'category_id','required' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Category','name' => 'category_id','required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
   <option value="">All categories</option>
   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($category->category_id); ?>" <?php if((string) ($filters['category_id'] ?? '') === (string) $category->category_id): echo 'selected'; endif; ?>><?php echo e($category->category_name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
  <button type="submit">Search</button>
 </form>

 <div class="pos-grid">
  <section>
   <h3>Products</h3>
   <div class="pos-products">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
     <div class="pos-product">
      <strong><?php echo e($product->product_name); ?></strong>
      <small><?php echo e($product->brand ?: 'No brand'); ?> &middot; <?php echo e($product->category?->category_name); ?></small>
      <span><?php echo e(money($product->unit_price)); ?> &middot; Stock: <?php echo e($product->stock_quantity); ?></span>
      <?php if($product->stock_quantity > 0): ?>
       <button type="button" class="add-product" data-product-id="<?php echo e($product->product_id); ?>" data-product-name="<?php echo e($product->product_name); ?>" data-price="<?php echo e($product->unit_price); ?>">Add</button>
      <?php else: ?>
       <button type="button" disabled>Out of stock</button>
      <?php endif; ?>
     </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
     <p>No products found.</p>
    <?php endif; ?>
   </div>
  </section>

  <section>
   <h3>Current sale</h3>
   <form method="POST" action="<?php echo e(route('sales.store')); ?>" id="sale-form">
    <?php echo csrf_field(); ?>
    <table>
     <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
     <tbody id="sale-lines"><tr id="empty-lines"><td colspan="5">Add products to begin.</td></tr></tbody>
     <tfoot><tr><th colspan="3" style="text-align:right">Total</th><th id="sale-total">₱0.00</th><th></th></tr></tfoot>
    </table>
    <div id="sale-fields"></div>
    <div class="form-grid">
     <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Amount paid','name' => 'amount_paid','prefix' => '₱','inputmode' => 'decimal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Amount paid','name' => 'amount_paid','prefix' => '₱','inputmode' => 'decimal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
     <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['label' => 'Payment method','name' => 'payment_method']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Payment method','name' => 'payment_method']); ?><option value="Cash">Cash</option><option value="GCash">GCash</option> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
     <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['label' => 'Registered customer','name' => 'customer_id','required' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Registered customer','name' => 'customer_id','required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
      <option value="">Walk-in customer</option>
      <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option value="<?php echo e($customer->customer_id); ?>"><?php echo e($customer->display_name); ?> (<?php echo e($customer->email); ?>)</option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
    </div>
    <p>Change due: <strong id="change-due">₱0.00</strong></p>
    <button type="submit">Complete sale</button>
   </form>
  </section>
 </div>
</div>
<?php $__env->startPush('head'); ?>
<style>
 .pos-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.3fr);gap:1rem}
 .pos-products{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:.6rem}
 .pos-product{display:grid;gap:.25rem;padding:.7rem;border:1px solid #ddd;border-radius:6px}
 .pos-product small{color:#666}.pos-product button{margin-top:.25rem}
 @media(max-width:800px){.pos-grid{grid-template-columns:1fr}}
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
 const lines = new Map(), tbody = document.getElementById('sale-lines'), fields = document.getElementById('sale-fields');
 const paid = document.querySelector('[name="amount_paid"]'), total = document.getElementById('sale-total'), change = document.getElementById('change-due');
 const money = value => new Intl.NumberFormat('en-PH', {style:'currency', currency:'PHP'}).format(value);
 function render() {
  tbody.innerHTML = ''; fields.innerHTML = ''; let sum = 0, index = 0;
  lines.forEach((line, id) => {
   const subtotal = line.price * line.quantity; sum += subtotal;
   const row = document.createElement('tr');
   row.innerHTML = `<td>${line.name}</td><td>${money(line.price)}</td><td><input type="number" min="1" value="${line.quantity}" data-qty="${id}" style="width:4rem"></td><td>${money(subtotal)}</td><td><button type="button" class="danger" data-remove="${id}">Remove</button></td>`;
   tbody.appendChild(row);
   fields.insertAdjacentHTML('beforeend', `<input type="hidden" name="items[${index}][product_id]" value="${id}"><input type="hidden" name="items[${index}][quantity]" value="${line.quantity}">`);
   index++;
  });
  if (!lines.size) tbody.innerHTML = '<tr id="empty-lines"><td colspan="5">Add products to begin.</td></tr>';
  total.textContent = money(sum); const tendered = parseFloat((paid.value || '').replace(/[₱,\s]/g, '')) || 0;
  change.textContent = money(Math.max(0, tendered - sum));
 }
 document.querySelectorAll('.add-product').forEach(button => button.addEventListener('click', () => {
  const id = button.dataset.productId, line = lines.get(id) || {name:button.dataset.productName, price:parseFloat(button.dataset.price), quantity:0};
  line.quantity++; lines.set(id, line); render();
 }));
 tbody.addEventListener('click', event => { if (event.target.dataset.remove) { lines.delete(event.target.dataset.remove); render(); } });
 tbody.addEventListener('input', event => { if (event.target.dataset.qty) { lines.get(event.target.dataset.qty).quantity = Math.max(1, parseInt(event.target.value || '1', 10)); render(); } });
 paid.addEventListener('input', render); render();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\sales\create.blade.php ENDPATH**/ ?>