<?php $__env->startSection('title','Waiting for a role'); ?>
<?php $__env->startSection('content'); ?>
<div class="card auth">
 <h2>Waiting for a role</h2>
 <p>Thanks for signing up, <strong><?php echo e(auth()->user()->label()); ?></strong>.</p>
 <p>Your account is created, but the administrator has not given you a role yet. Once they do, log in again and you will see the parts of the system that your role can use.</p>
 <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button>Log out</button></form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/auth/pending.blade.php ENDPATH**/ ?>