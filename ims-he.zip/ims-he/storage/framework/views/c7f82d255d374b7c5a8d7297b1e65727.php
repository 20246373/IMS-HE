<!doctype html><html lang="en"><head><meta charset="utf-8"><style>
body{font-family:DejaVu Sans,sans-serif;font-size:10px;color:#222}h1{font-size:18px}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #ddd;padding:7px;text-align:left}.amount{text-align:right}
</style></head><body>
<h1>Financial report</h1><p><?php echo e(\Illuminate\Support\Carbon::parse($startDate)->format('M d, Y')); ?> - <?php echo e(\Illuminate\Support\Carbon::parse($endDate)->format('M d, Y')); ?></p>
<p><strong>Income:</strong> <?php echo e(money($report['totalIncome'])); ?> &nbsp; <strong>Expense:</strong> <?php echo e(money($report['totalExpense'])); ?> &nbsp; <strong>Net:</strong> <?php echo e(money($report['totalNet'])); ?></p>
<table><thead><tr><th>Date</th><th class="amount">Income</th><th class="amount">Expense</th><th class="amount">Net</th></tr></thead><tbody>
<?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e(\Illuminate\Support\Carbon::parse($day['date'])->format('M d, Y')); ?></td><td class="amount"><?php echo e(money($day['income'])); ?></td><td class="amount"><?php echo e(money($day['expense'])); ?></td><td class="amount"><?php echo e(money($day['net'])); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody></table></body></html>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\reports\pdf\financial.blade.php ENDPATH**/ ?>