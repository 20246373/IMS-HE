<?php $__env->startSection('title','Online order #'.$invoice->invoice_id); ?>
<?php $__env->startSection('content'); ?>
<p><a href="<?php echo e(route('online-orders.index')); ?>">Back to online orders</a></p>
<div class="card" style="max-width:760px">
 <h2>Online order #<?php echo e($invoice->invoice_id); ?> <?php echo $__env->make('orders._status', ['status' => $invoice->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></h2>

 <div class="form-grid">
  <p>
   <strong>Customer</strong><br>
   <?php if($invoice->customer): ?>
    <?php echo e(trim($invoice->customer->first_name.' '.$invoice->customer->last_name)); ?><br>
    <?php echo e($invoice->customer->email); ?><br>
    <?php echo e($invoice->customer->contact_number); ?><br>
    <?php echo e($invoice->customer->address); ?>

   <?php else: ?>
    Deleted account
   <?php endif; ?>
  </p>
  <p>
   <strong>Order</strong><br>
   Date: <?php echo e($invoice->invoice_date->format('M d, Y')); ?><br>
   Payment method: <?php echo e($invoice->payment?->payment_method); ?><br>
   Total: <strong><?php echo e(money($invoice->total_amount)); ?></strong>
  </p>
 </div>

 <table class="cart-table">
  <tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr>
  <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($line->product->product_name); ?></td>
    <td><?php echo e(money($line->price)); ?></td>
    <td><?php echo e($line->quantity); ?></td>
    <td><?php echo e(money($line->subtotal)); ?></td>
   </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tr class="cart-total-row"><th colspan="3">Total</th><th><?php echo e(money($invoice->total_amount)); ?></th></tr>
 </table>

 <?php if($invoice->status === 'Pending'): ?>
  <p>
   <form method="POST" action="<?php echo e(route('online-orders.complete', $invoice)); ?>" class="inline"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
    <button>Mark as Completed</button>
   </form>
   <form method="POST" action="<?php echo e(route('online-orders.cancel', $invoice)); ?>" class="inline"
         onsubmit="return confirm('Cancel order #<?php echo e($invoice->invoice_id); ?>? The items go back into stock. This cannot be undone.')"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
    <button class="danger">Cancel order</button>
   </form>
  </p>
 <?php else: ?>
  <p><small>This order is <?php echo e($invoice->status); ?> and can no longer be changed.</small></p>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\orders\manage\show.blade.php ENDPATH**/ ?>