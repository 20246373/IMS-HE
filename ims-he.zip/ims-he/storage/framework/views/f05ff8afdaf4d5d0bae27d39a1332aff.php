<?php $__env->startSection('title', 'Receipt #'.$invoice->invoice_id); ?>
<?php $__env->startSection('content'); ?>
<div class="card receipt" id="receipt">
 <h2>Ibay Enterprises Corporation</h2>
 <p>Receipt #<?php echo e($invoice->invoice_id); ?><br>Date: <?php echo e($invoice->invoice_date->format('M d, Y')); ?><br>Cashier: <?php echo e($cashierName); ?><br>Customer: <?php echo e($invoice->customer?->display_name ?: 'Walk-in customer'); ?></p>
 <table>
  <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
  <tbody>
   <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><?php echo e($line->product->product_name); ?></td><td><?php echo e(money($line->price)); ?></td><td><?php echo e($line->quantity); ?></td><td><?php echo e(money($line->subtotal)); ?></td></tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <tr><th colspan="3" style="text-align:right">Total</th><th><?php echo e(money($invoice->total_amount)); ?></th></tr>
  </tbody>
 </table>
 <p>Paid: <?php echo e(money($invoice->payment?->amount_paid)); ?><br>Change: <?php echo e(money($invoice->payment?->change_amount)); ?><br>Method: <?php echo e($invoice->payment?->payment_method); ?></p>
 <p class="no-print"><button type="button" onclick="window.print()">Print</button> <a class="btn btn-alt" href="<?php echo e(route('sales.create')); ?>">New sale</a></p>
</div>
<?php $__env->startPush('head'); ?>
<style>
 @media print {
  nav,.no-print,[role=alert]{display:none!important} body{background:#fff} main{margin:0!important;padding:0!important;width:80mm!important;max-width:80mm!important}.receipt{box-shadow:none;padding:0!important;margin:0!important;width:80mm!important;max-width:80mm!important;font-size:11px}.receipt table{font-size:10px}
 }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\sales\show.blade.php ENDPATH**/ ?>