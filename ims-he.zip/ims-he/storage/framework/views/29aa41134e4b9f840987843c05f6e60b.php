<?php $__env->startSection('title','Log in'); ?>
<?php $__env->startSection('content'); ?>
<div class="card auth">
 <h2>Log in</h2>
 <form method="POST" action="<?php echo e(route('login')); ?>"><?php echo csrf_field(); ?>
  <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
  <div class="form-grid">
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Email or username','name' => 'login','value' => ''.e(old('login')).'','maxlength' => '100','autocomplete' => 'username','autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email or username','name' => 'login','value' => ''.e(old('login')).'','maxlength' => '100','autocomplete' => 'username','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Password','name' => 'password','type' => 'password','id' => 'login-password','autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Password','name' => 'password','type' => 'password','id' => 'login-password','autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
  </div>
  <label class="optional" style="font-weight:400"><input type="checkbox" style="display:inline;width:auto" onclick="document.getElementById('login-password').type = this.checked ? 'text' : 'password'"> Show password</label>
  <p><button>Log in</button></p>
 </form>
 <p>New here? <a href="<?php echo e(route('customer.register')); ?>">Sign up</a></p>
 <p><small>Work here? <a href="<?php echo e(route('staff.register')); ?>">Request employee access</a></small></p>
 <p><a href="<?php echo e(route('password.forgot')); ?>">Forgot your password?</a></p>

 <?php if(session('dev_verification_url')): ?>
  <p><small>Local dev only: <a href="<?php echo e(session('dev_verification_url')); ?>">open the verification link</a></small></p>
 <?php endif; ?>

 <details>
  <summary><small>Did not get the verification email?</small></summary>
  <form method="POST" action="<?php echo e(route('customer.verification.resend')); ?>"><?php echo csrf_field(); ?>
   <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Your email','name' => 'email','type' => 'email','maxlength' => '100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Your email','name' => 'email','type' => 'email','maxlength' => '100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
   <p><button>Resend verification email</button></p>
  </form>
 </details>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/auth/login.blade.php ENDPATH**/ ?>