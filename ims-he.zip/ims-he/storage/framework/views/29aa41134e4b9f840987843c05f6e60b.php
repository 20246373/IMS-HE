<?php $__env->startSection('title','Log in'); ?>
<?php $__env->startSection('content'); ?>
<div class="card auth">
 <?php if(! $as): ?>
  
  <h2>Welcome</h2>
  <p class="auth-sub">Log in to continue to IMS-HE.</p>
  <p class="choice-label">Log in as</p>
  <?php echo $__env->make('partials.auth-choices', ['customerUrl' => route('login', ['as' => 'customer']), 'employeeUrl' => route('login', ['as' => 'employee'])], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <div class="auth-links">
   <span>Don't have an account? <a href="<?php echo e(route('register')); ?>">Sign up</a></span>
  </div>
 <?php else: ?>
  
  <a class="auth-back" href="<?php echo e(route('login')); ?>">Change access</a>
  <h2><?php echo e($as === 'customer' ? 'Customer log in' : 'Employee log in'); ?></h2>
  <p class="auth-sub">Enter your email and password to continue.</p>
  <form method="POST" action="<?php echo e(route('login')); ?>"><?php echo csrf_field(); ?>
   <div class="form-grid">
    <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Email','name' => 'login','type' => 'email','value' => ''.e(old('login')).'','maxlength' => '100','autocomplete' => 'email','autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','name' => 'login','type' => 'email','value' => ''.e(old('login')).'','maxlength' => '100','autocomplete' => 'email','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala7a729e2918fc1247311e0d0672d15e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7a729e2918fc1247311e0d0672d15e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.password','data' => ['id' => 'login-password','autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'login-password','autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7a729e2918fc1247311e0d0672d15e1)): ?>
<?php $attributes = $__attributesOriginala7a729e2918fc1247311e0d0672d15e1; ?>
<?php unset($__attributesOriginala7a729e2918fc1247311e0d0672d15e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7a729e2918fc1247311e0d0672d15e1)): ?>
<?php $component = $__componentOriginala7a729e2918fc1247311e0d0672d15e1; ?>
<?php unset($__componentOriginala7a729e2918fc1247311e0d0672d15e1); ?>
<?php endif; ?>
   </div>
   <p><button>Log in</button></p>
  </form>

  
  <?php if(session('unverified_email')): ?>
   <form method="POST" action="<?php echo e(route('customer.verification.resend')); ?>"><?php echo csrf_field(); ?>
    <input type="hidden" name="email" value="<?php echo e(session('unverified_email')); ?>">
    <p><button class="btn-alt">Resend verification email</button></p>
   </form>
  <?php endif; ?>

  <?php if(session('dev_verification_url')): ?>
   <p><small>Local dev only: <a href="<?php echo e(session('dev_verification_url')); ?>">open the verification link</a></small></p>
  <?php endif; ?>

  <div class="auth-links">
   <a href="<?php echo e(route('password.forgot')); ?>">Forgot your password?</a>
   <span>Don't have an account? <a href="<?php echo e(route($as === 'customer' ? 'customer.register' : 'staff.register')); ?>">Sign up</a></span>
  </div>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/auth/login.blade.php ENDPATH**/ ?>