<?php $__env->startSection('title', 'Sales report'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading">
  <h2>Sales report</h2>
  <a class="btn no-print" href="<?php echo e(route('reports.sales.download', array_filter(['start_date' => $startDate, 'end_date' => $endDate, 'category_id' => $categoryId]))); ?>">Save as PDF</a>
 </div>
 <form method="GET" action="<?php echo e(route('reports.sales')); ?>" class="no-print report-filter">
  <label>From <input type="date" name="start_date" value="<?php echo e($startDate); ?>" required></label>
  <label>To <input type="date" name="end_date" value="<?php echo e($endDate); ?>" required></label>
  <label>Category
   <select name="category_id">
    <option value="">All categories</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($category->category_id); ?>" <?php if((int) $categoryId === (int) $category->category_id): echo 'selected'; endif; ?>><?php echo e($category->category_name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </label>
  <button type="submit">Apply filter</button>
 </form>
 <div class="report-summary">
  <div><strong>Total revenue</strong><span><?php echo e(money($report['totalRevenue'])); ?></span></div>
  <div><strong>Total transactions</strong><span><?php echo e(number_format($report['totalTransactions'])); ?></span></div>
 </div>
 <h3>Sales by category</h3>
 <table>
  <thead><tr><th>Category</th><th>Units</th><th>Revenue</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['categorySales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorySale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr><td><?php echo e($categorySale->category_name); ?></td><td><?php echo e(number_format($categorySale->units)); ?></td><td><?php echo e(money($categorySale->revenue)); ?></td></tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="3">No completed sales for this date range.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <h3>Completed sales</h3>
 <table>
  <thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>Total</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['sales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr>
    <td>#<?php echo e($sale->invoice_id); ?></td>
    <td><?php echo e(\Illuminate\Support\Carbon::parse($sale->invoice_date)->format('M d, Y')); ?></td>
    <td><?php echo e(trim(($sale->first_name ?? '') . ' ' . ($sale->last_name ?? '')) ?: 'Walk-in customer'); ?></td>
    <td><?php echo e(money($sale->total_amount)); ?></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="4">No completed sales for this date range.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\reports\sales.blade.php ENDPATH**/ ?>