<?php $__env->startSection('title', 'Ledger'); ?>
<?php $__env->startSection('heading', 'Ledger'); ?>
<?php $__env->startSection('page-actions'); ?><a class="btn" href="<?php echo e(route('ledger.create')); ?>">New entry</a><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <form method="GET" action="<?php echo e(route('ledger.index')); ?>" class="report-filter">
  <label>From <input type="date" name="start_date" value="<?php echo e($startDate); ?>" required></label>
  <label>To <input type="date" name="end_date" value="<?php echo e($endDate); ?>" required></label>
  <label>Type <select name="entry_type"><option value="">All</option><option value="Income" <?php if($type === 'Income'): echo 'selected'; endif; ?>>Income</option><option value="Expense" <?php if($type === 'Expense'): echo 'selected'; endif; ?>>Expense</option></select></label>
  <button type="submit">Apply filter</button>
 </form>
 <div class="report-summary">
  <div><strong>Income</strong><span><?php echo e(money($totals['Income'])); ?></span></div>
  <div><strong>Expense</strong><span><?php echo e(money($totals['Expense'])); ?></span></div>
  <div><strong>Net</strong><span><?php echo e(money($totals['Net'])); ?></span></div>
 </div>
 <table>
  <thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Description</th><th>Reference</th><th>Recorded by</th><th>Actions</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr>
    <td><?php echo e($entry->entry_date->format('M d, Y')); ?></td><td><?php echo e($entry->entry_type); ?></td><td><?php echo e(money($entry->amount)); ?></td>
    <td><?php echo e($entry->description); ?></td><td><?php echo e($entry->reference_type ? $entry->reference_type.' #'.$entry->reference_id : '—'); ?></td>
    <td><?php echo e($entry->recorder?->displayName() ?? 'System'); ?></td>
    <td><form method="POST" action="<?php echo e(route('ledger.reverse', $entry)); ?>" class="inline"><?php echo csrf_field(); ?> <?php echo method_field('POST'); ?><button class="danger" onclick="return confirm('Reverse this entry?')">Reverse</button></form></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="7">No ledger entries for this date range.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <?php echo e($entries->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/ledger/index.blade.php ENDPATH**/ ?>