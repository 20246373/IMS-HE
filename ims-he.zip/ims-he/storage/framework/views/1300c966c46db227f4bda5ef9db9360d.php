
<span class="stepper">
 <button type="button" data-step="-1" aria-label="Decrease quantity">&minus;</button>
 <input type="number" name="quantity" value="<?php echo e($value); ?>" min="1" max="<?php echo e($max); ?>" required>
 <button type="button" data-step="1" aria-label="Increase quantity">+</button>
</span>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/partials/qty.blade.php ENDPATH**/ ?>