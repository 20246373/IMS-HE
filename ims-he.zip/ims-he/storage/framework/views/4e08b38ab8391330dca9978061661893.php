<?php $__env->startSection('title', 'Attendance period'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading"><h2>Attendance period</h2><a class="btn btn-alt" href="<?php echo e(route('attendance.day')); ?>">Daily view</a></div>
 <form method="GET" action="<?php echo e(route('attendance.period')); ?>" class="report-filter">
  <label>From <input type="date" name="start_date" value="<?php echo e($startDate); ?>" required></label>
  <label>To <input type="date" name="end_date" value="<?php echo e($endDate); ?>" required></label>
  <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['label' => 'Employee','name' => 'employee_id','required' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Employee','name' => 'employee_id','required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
   <option value="">All employees</option>
   <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($employee->employee_id); ?>" <?php if((string) $employeeId === (string) $employee->employee_id): echo 'selected'; endif; ?>><?php echo e($employee->full_name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
  <button type="submit">Apply filter</button>
 </form>
 <table>
  <thead><tr><th>Date</th><th>Employee</th><th>Time in</th><th>Time out</th><th>Overtime</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td><?php echo e($record->work_date->format('M d, Y')); ?></td>
     <td><?php echo e($record->employee->full_name); ?></td>
     <td><?php echo e($record->time_in); ?></td>
     <td><?php echo e($record->time_out ?: '—'); ?></td>
     <td><?php echo e(number_format((float) $record->overtime_hours, 2)); ?> hours</td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="5">No attendance records found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <?php echo e($records->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/attendance/period.blade.php ENDPATH**/ ?>