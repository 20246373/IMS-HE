<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <style>
  body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #222; }
  h1 { font-size: 18px; margin-bottom: 4px; }
  p { color: #555; margin-top: 0; }
  .summary { margin: 18px 0; }
  .summary span { display: inline-block; margin-right: 28px; }
  table { width: 100%; border-collapse: collapse; }
  th, td { border-bottom: 1px solid #ddd; padding: 7px; text-align: left; }
  th { background: #f0f2f5; }
  .amount { text-align: right; }
 </style>
</head>
<body>
 <h1>Sales report</h1>
 <p><?php echo e(\Illuminate\Support\Carbon::parse($startDate)->format('M d, Y')); ?> - <?php echo e(\Illuminate\Support\Carbon::parse($endDate)->format('M d, Y')); ?></p>
 <div class="summary">
  <span><strong>Total revenue:</strong> <?php echo e(money($report['totalRevenue'])); ?></span>
  <span><strong>Total transactions:</strong> <?php echo e(number_format($report['totalTransactions'])); ?></span>
 </div>
 <h2>Sales by category</h2>
 <table>
  <thead><tr><th>Category</th><th>Units</th><th class="amount">Revenue</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['categorySales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorySale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr><td><?php echo e($categorySale->category_name); ?></td><td><?php echo e(number_format($categorySale->units)); ?></td><td class="amount"><?php echo e(money($categorySale->revenue)); ?></td></tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="3">No completed sales for this date range.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <h2>Completed sales</h2>
 <table>
  <thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th class="amount">Total</th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['sales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr>
    <td>#<?php echo e($sale->invoice_id); ?></td>
    <td><?php echo e(\Illuminate\Support\Carbon::parse($sale->invoice_date)->format('M d, Y')); ?></td>
    <td><?php echo e(trim(($sale->first_name ?? '') . ' ' . ($sale->last_name ?? '')) ?: 'Walk-in customer'); ?></td>
    <td class="amount"><?php echo e(money($sale->total_amount)); ?></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="4">No completed sales for this date range.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
</body>
</html>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\reports\pdf\sales.blade.php ENDPATH**/ ?>