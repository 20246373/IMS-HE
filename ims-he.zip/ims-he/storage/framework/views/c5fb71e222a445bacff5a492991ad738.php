<?php $__env->startSection('title', 'Procurement report'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading">
  <h2>Procurement report</h2>
  <a class="btn no-print"
     href="<?php echo e(route('reports.procurement.download', array_filter([
         'start_date' => $startDate,
         'end_date' => $endDate,
         'supplier_id' => $supplierId,
         'category_id' => $categoryId,
     ]))); ?>">
   Save as PDF
  </a>
 </div>

 <form method="GET" action="<?php echo e(route('reports.procurement')); ?>" class="no-print report-filter">
  <label>From
   <input type="date" name="start_date" value="<?php echo e($startDate); ?>" required>
  </label>
  <label>To
   <input type="date" name="end_date" value="<?php echo e($endDate); ?>" required>
  </label>
  <label>Supplier
   <select name="supplier_id">
    <option value="">All suppliers</option>
    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($supplier->supplier_id); ?>"
       <?php if((int) $supplierId === (int) $supplier->supplier_id): echo 'selected'; endif; ?>>
      <?php echo e($supplier->supplier_name); ?>

     </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </label>
  <label>Category
   <select name="category_id">
    <option value="">All categories</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($category->category_id); ?>"
       <?php if((int) $categoryId === (int) $category->category_id): echo 'selected'; endif; ?>>
      <?php echo e($category->category_name); ?>

     </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </label>
  <button type="submit">Apply filter</button>
 </form>

 <div class="report-summary">
  <div><strong>Purchase orders</strong><span><?php echo e(number_format($report['summary']['purchaseOrderCount'])); ?></span></div>
  <div><strong>Ordered value</strong><span><?php echo e(money($report['summary']['orderedValue'])); ?></span></div>
  <div><strong>Received value</strong><span><?php echo e(money($report['summary']['receivedValue'])); ?></span></div>
  <div><strong>Deliveries</strong><span><?php echo e(number_format($report['summary']['deliveryCount'])); ?></span></div>
  <div><strong>Units delivered</strong><span><?php echo e(number_format($report['summary']['deliveredUnits'])); ?></span></div>
 </div>

 <h3>Purchase orders</h3>
 <table>
  <thead>
   <tr>
    <th>PO #</th>
    <th>Supplier</th>
    <th>Order date</th>
    <th>Status</th>
    <th>Ordered qty</th>
    <th>Received qty</th>
    <th>Ordered value</th>
    <th>Received value</th>
   </tr>
  </thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['purchaseOrders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td><a href="<?php echo e(route('purchase-orders.show', $purchaseOrder->po_id)); ?>">PO #<?php echo e($purchaseOrder->po_id); ?></a></td>
     <td><?php echo e($purchaseOrder->supplier_name); ?></td>
     <td><?php echo e(\Illuminate\Support\Carbon::parse($purchaseOrder->order_date)->format('M d, Y')); ?></td>
     <td><?php echo e($purchaseOrder->status); ?></td>
     <td><?php echo e(number_format($purchaseOrder->ordered_quantity)); ?></td>
     <td><?php echo e(number_format($purchaseOrder->received_quantity)); ?></td>
     <td><?php echo e(money($purchaseOrder->ordered_value)); ?></td>
     <td><?php echo e(money($purchaseOrder->received_value)); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="8">No purchase orders found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>

 <h3>Purchase order items</h3>
 <table>
  <thead>
   <tr>
    <th>PO #</th>
    <th>Product</th>
    <th>Category</th>
    <th>Ordered</th>
    <th>Received</th>
    <th>Unit cost</th>
    <th>Subtotal</th>
   </tr>
  </thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['orderItems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td>PO #<?php echo e($item->po_id); ?></td>
     <td><?php echo e($item->product_name); ?></td>
     <td><?php echo e($item->category_name ?? 'Uncategorized'); ?></td>
     <td><?php echo e(number_format($item->quantity)); ?></td>
     <td><?php echo e(number_format($item->quantity_received)); ?></td>
     <td><?php echo e(money($item->unit_cost)); ?></td>
     <td><?php echo e(money($item->subtotal)); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="7">No purchase order items found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>

 <h3>Deliveries</h3>
 <table>
  <thead>
   <tr>
    <th>Date</th>
    <th>PO #</th>
    <th>Supplier</th>
    <th>Product</th>
    <th>Category</th>
    <th>Quantity</th>
   </tr>
  </thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['deliveries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td><?php echo e(\Illuminate\Support\Carbon::parse($delivery->transaction_date)->format('M d, Y')); ?></td>
     <td>PO #<?php echo e($delivery->po_id); ?></td>
     <td><?php echo e($delivery->supplier_name); ?></td>
     <td><?php echo e($delivery->product_name); ?></td>
     <td><?php echo e($delivery->category_name ?? 'Uncategorized'); ?></td>
     <td><?php echo e(number_format($delivery->quantity)); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="6">No deliveries found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>

 <h3>Supplier spend</h3>
 <table>
  <thead>
   <tr>
    <th>Supplier</th>
    <th>Purchase orders</th>
    <th>Ordered value</th>
    <th>Received value</th>
   </tr>
  </thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $report['supplierSpend']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
     <td><?php echo e($supplier->supplier_name); ?></td>
     <td><?php echo e(number_format($supplier->po_count)); ?></td>
     <td><?php echo e(money($supplier->ordered_value)); ?></td>
     <td><?php echo e(money($supplier->received_value)); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="4">No supplier spend found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\reports\procurement.blade.php ENDPATH**/ ?>