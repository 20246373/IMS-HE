
<span class="status status-<?php echo e(strtolower($status)); ?>"><?php echo e($status); ?></span>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\orders\_status.blade.php ENDPATH**/ ?>