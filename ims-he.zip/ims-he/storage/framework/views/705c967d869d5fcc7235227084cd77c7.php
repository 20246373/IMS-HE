<div class="card">
 <h3>Pending Purchase Orders <span>(<?php echo e($pendingPurchaseOrderCount); ?>)</span></h3>
 <?php if($pendingPurchaseOrders->isEmpty()): ?>
  <p>No pending purchase orders.</p>
 <?php else: ?>
  <table>
   <tr><th>PO</th><th>Supplier</th><th>Date</th><th>Total</th></tr>
   <?php $__currentLoopData = $pendingPurchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><a href="<?php echo e(route('purchase-orders.show', $purchaseOrder)); ?>">PO #<?php echo e($purchaseOrder->po_id); ?></a></td>
    <td><?php echo e($purchaseOrder->supplier->supplier_name); ?></td>
    <td><?php echo e($purchaseOrder->order_date->format('M d, Y')); ?></td>
    <td><?php echo e(money($purchaseOrder->items->sum('subtotal'))); ?></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
 <?php endif; ?>
</div>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\dashboard\_pending-pos.blade.php ENDPATH**/ ?>