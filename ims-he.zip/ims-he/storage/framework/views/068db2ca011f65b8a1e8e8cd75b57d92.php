<?php $__env->startSection('title','Sign up'); ?>
<?php $__env->startSection('content'); ?>
<div class="card auth">
 <h2>Sign up</h2>
 <form method="POST" action="<?php echo e(route('customer.register')); ?>"><?php echo csrf_field(); ?>
  <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
  <div class="form-grid">
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Email','name' => 'email','type' => 'email','value' => ''.e(old('email')).'','maxlength' => '100','autocomplete' => 'email','autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','name' => 'email','type' => 'email','value' => ''.e(old('email')).'','maxlength' => '100','autocomplete' => 'email','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Password (at least 8 characters)','name' => 'password','type' => 'password','id' => 'signup-password','minlength' => '8','maxlength' => '72','autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Password (at least 8 characters)','name' => 'password','type' => 'password','id' => 'signup-password','minlength' => '8','maxlength' => '72','autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
  </div>
  <label class="optional" style="font-weight:400"><input type="checkbox" style="display:inline;width:auto" onclick="document.getElementById('signup-password').type = this.checked ? 'text' : 'password'"> Show password</label>
  <p><button>Sign up</button></p>
 </form>
 <p>Have an account? <a href="<?php echo e(route('login')); ?>">Log in</a></p>
 <p><small>Work here? <a href="<?php echo e(route('staff.register')); ?>">Request employee access</a></small></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/customer/register.blade.php ENDPATH**/ ?>