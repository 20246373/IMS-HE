<?php $__env->startSection('title','Customer sign up'); ?>
<?php $__env->startSection('content'); ?>
<div class="card auth">
 <a class="auth-back" href="<?php echo e(route('register')); ?>">Change access</a>
 <h2>Customer sign up</h2>
 <form method="POST" action="<?php echo e(route('customer.register')); ?>"><?php echo csrf_field(); ?>
  <div class="form-grid">
   <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['label' => 'Email','name' => 'email','type' => 'email','value' => ''.e(old('email')).'','maxlength' => '100','autocomplete' => 'email','autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','name' => 'email','type' => 'email','value' => ''.e(old('email')).'','maxlength' => '100','autocomplete' => 'email','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
   <?php if (isset($component)) { $__componentOriginala7a729e2918fc1247311e0d0672d15e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7a729e2918fc1247311e0d0672d15e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.password','data' => ['id' => 'signup-password','hint' => 'Must be at least 8 characters.','minlength' => '8','maxlength' => '72','autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'signup-password','hint' => 'Must be at least 8 characters.','minlength' => '8','maxlength' => '72','autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7a729e2918fc1247311e0d0672d15e1)): ?>
<?php $attributes = $__attributesOriginala7a729e2918fc1247311e0d0672d15e1; ?>
<?php unset($__attributesOriginala7a729e2918fc1247311e0d0672d15e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7a729e2918fc1247311e0d0672d15e1)): ?>
<?php $component = $__componentOriginala7a729e2918fc1247311e0d0672d15e1; ?>
<?php unset($__componentOriginala7a729e2918fc1247311e0d0672d15e1); ?>
<?php endif; ?>
  </div>
  <p><button>Sign up</button></p>
 </form>
 <div class="auth-links">
  <span>Already have an account? <a href="<?php echo e(route('login', ['as' => 'customer'])); ?>">Log in</a></span>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/customer/register.blade.php ENDPATH**/ ?>