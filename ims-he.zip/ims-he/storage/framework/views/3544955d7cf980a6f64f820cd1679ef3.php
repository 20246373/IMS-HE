<?php $__env->startSection('title','Products'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <h2>Products</h2>
 <form method="GET" action="<?php echo e(route('catalog.index')); ?>" class="search">
  <input name="q" value="<?php echo e($q); ?>" placeholder="Search by name" maxlength="100">
  <select name="category">
   <option value="">All categories</option>
   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($c->category_id); ?>" <?php if($categoryId == $c->category_id): echo 'selected'; endif; ?>><?php echo e($c->category_name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <button>Filter</button>
  <?php if($q !== '' || $categoryId): ?><a href="<?php echo e(route('catalog.index')); ?>">Clear</a><?php endif; ?>
 </form>
</div>

<?php if($products->isEmpty()): ?>
 <div class="card">No products match your search.</div>
<?php else: ?>
 <p><?php echo e($products->total()); ?> product(s)</p>
 <div class="grid"><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo $__env->make('catalog._card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
 <?php if($products->hasPages()): ?>
  <p class="pager">
   <?php if($products->onFirstPage()): ?><span>Previous</span><?php else: ?><a href="<?php echo e($products->previousPageUrl()); ?>">Previous</a><?php endif; ?>
   <span>Page <?php echo e($products->currentPage()); ?> of <?php echo e($products->lastPage()); ?></span>
   <?php if($products->hasMorePages()): ?><a href="<?php echo e($products->nextPageUrl()); ?>">Next</a><?php else: ?><span>Next</span><?php endif; ?>
  </p>
 <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/catalog/index.blade.php ENDPATH**/ ?>