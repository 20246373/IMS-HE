<?php $__env->startSection('title','Products'); ?>
<?php $__env->startSection('heading', 'Products'); ?>
<?php $__env->startSection('content'); ?>
<div class="shop">
 <aside class="shop-side">
  <div class="card">
   <h3>Filter</h3>
   <form method="GET" action="<?php echo e(route('catalog.index')); ?>">
    <label>Search</label>
    <input name="q" value="<?php echo e($q); ?>" placeholder="Name or brand" maxlength="100">
    <label>Category</label>
    <select name="category" aria-label="Category">
     <option value="">All categories</option>
     <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($c->category_id); ?>" <?php if($categoryId == $c->category_id): echo 'selected'; endif; ?>><?php echo e($c->category_name); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label>Brand</label>
    <select name="brand" aria-label="Brand">
     <option value="">All brands</option>
     <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($b); ?>" <?php if($brand === $b): echo 'selected'; endif; ?>><?php echo e($b); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn">Apply Filters</button>
    <?php if($q !== '' || $categoryId || $brand !== ''): ?><a href="<?php echo e(route('catalog.index')); ?>">Clear</a><?php endif; ?>
   </form>
  </div>

  <div class="card shop-cats">
   <h4>Categories</h4>
   <a href="<?php echo e(route('catalog.index', array_filter(['q' => $q, 'brand' => $brand]))); ?>"
      class="<?php echo e(!$categoryId ? 'active' : ''); ?>">All categories <small><?php echo e($categories->sum('products_count')); ?></small></a>
   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('catalog.index', array_filter(['q' => $q, 'brand' => $brand, 'category' => $c->category_id]))); ?>"
       class="<?php echo e($categoryId == $c->category_id ? 'active' : ''); ?>">
     <?php echo e($c->category_name); ?> <small><?php echo e($c->products_count); ?></small>
    </a>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
 </aside>

 <div class="shop-main">
  <p class="shop-count"><?php echo e($products->total()); ?> product(s)</p>

  <?php if($products->isEmpty()): ?>
   <div class="card">No products match your search.</div>
  <?php else: ?>
   <div class="grid"><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo $__env->make('catalog._card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
   <?php if($products->hasPages()): ?>
    <p class="pager">
     <?php if($products->onFirstPage()): ?><span>Previous</span><?php else: ?><a href="<?php echo e($products->previousPageUrl()); ?>">Previous</a><?php endif; ?>
     <span>Page <?php echo e($products->currentPage()); ?> of <?php echo e($products->lastPage()); ?></span>
     <?php if($products->hasMorePages()): ?><a href="<?php echo e($products->nextPageUrl()); ?>">Next</a><?php else: ?><span>Next</span><?php endif; ?>
    </p>
   <?php endif; ?>
  <?php endif; ?>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/catalog/index.blade.php ENDPATH**/ ?>