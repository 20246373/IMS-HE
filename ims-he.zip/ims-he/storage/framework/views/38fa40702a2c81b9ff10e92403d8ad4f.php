<?php $__env->startSection('title','Sign up'); ?>
<?php $__env->startSection('content'); ?>
<div class="card auth">
 <h2>Sign up</h2>
 <p class="choice-label">Sign up as</p>
 <div class="choice-list">
  <a href="<?php echo e(route('customer.register')); ?>">Customer</a>
  <a href="<?php echo e(route('staff.register')); ?>">Employee</a>
 </div>
 <div class="auth-links">
  <span>Already have an account? <a href="<?php echo e(route('login')); ?>">Log in</a></span>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/auth/register-choose.blade.php ENDPATH**/ ?>