<?php $__env->startSection('title', $supplier->exists ? 'Edit supplier' : 'Add supplier'); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:560px">
 <h2><?php echo e($supplier->exists ? 'Edit supplier' : 'Add supplier'); ?></h2>
 <form method="POST" action="<?php echo e($supplier->exists ? route('suppliers.update', $supplier) : route('suppliers.store')); ?>">
  <?php echo csrf_field(); ?>
  <?php if($supplier->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
  <?php if($supplier->exists): ?>
   <label>Supplier name</label>
   <input value="<?php echo e($supplier->supplier_name); ?>" readonly>
  <?php else: ?>
   <label>Supplier name
    <input name="supplier_name" value="<?php echo e(old('supplier_name')); ?>" maxlength="100" required>
   </label>
  <?php endif; ?>
  <label>Contact number
   <input name="contact_number" value="<?php echo e(old('contact_number', $supplier->contact_number)); ?>" maxlength="14" required>
  </label>
  <label>Address
   <input name="address" value="<?php echo e(old('address', $supplier->address)); ?>" maxlength="100" required>
  </label>
  <p>
   <button><?php echo e($supplier->exists ? 'Save changes' : 'Add supplier'); ?></button>
   <a class="btn" href="<?php echo e(route('suppliers.index')); ?>">Cancel</a>
  </p>
 </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\suppliers\form.blade.php ENDPATH**/ ?>