<?php $__env->startSection('title', 'Daily attendance'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading"><h2>Daily attendance</h2><a class="btn btn-alt" href="<?php echo e(route('attendance.period')); ?>">Period view</a></div>
 <form method="GET" action="<?php echo e(route('attendance.day')); ?>" class="report-filter">
  <label>Date <input type="date" name="date" value="<?php echo e($date); ?>" required></label>
  <button type="submit">Show day</button>
 </form>
 <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
 <form method="POST" action="<?php echo e(route('attendance.day.save')); ?>">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="work_date" value="<?php echo e($date); ?>">
  <table>
   <thead><tr><th>Employee</th><th>Time in</th><th>Time out</th><th>Overtime hours</th></tr></thead>
   <tbody>
    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php ($record = $records->get($employee->employee_id)); ?>
     <tr>
      <td><?php echo e($employee->full_name); ?><input type="hidden" name="records[<?php echo e($employee->employee_id); ?>][employee_id]" value="<?php echo e($employee->employee_id); ?>"></td>
      <td><input type="time" name="records[<?php echo e($employee->employee_id); ?>][time_in]" value="<?php echo e($record?->time_in ? substr($record->time_in, 0, 5) : ''); ?>"></td>
      <td><input type="time" name="records[<?php echo e($employee->employee_id); ?>][time_out]" value="<?php echo e($record?->time_out ? substr($record->time_out, 0, 5) : ''); ?>"></td>
      <td><input type="number" name="records[<?php echo e($employee->employee_id); ?>][overtime_hours]" value="<?php echo e($record?->overtime_hours); ?>" min="0" max="12" step=".25" placeholder="Auto"></td>
     </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
  </table>
  <p><button type="submit">Save attendance</button></p>
 </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\attendance\day.blade.php ENDPATH**/ ?>