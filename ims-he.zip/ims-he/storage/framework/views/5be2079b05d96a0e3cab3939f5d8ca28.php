<?php $__env->startSection('title', 'Employees'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading">
  <h2>Employees</h2>
  <a class="btn" href="<?php echo e(route('employees.create')); ?>">+ Add employee</a>
 </div>
 <form method="GET" action="<?php echo e(route('employees.index')); ?>" class="report-filter">
  <label>Search name <input type="search" name="q" value="<?php echo e($search); ?>" placeholder="First or last name"></label>
  <button type="submit">Search</button>
  <?php if($search !== ''): ?><a class="btn btn-alt" href="<?php echo e(route('employees.index')); ?>">Clear</a><?php endif; ?>
 </form>
 <table>
  <thead><tr><th>Name</th><th>Position</th><th>Status</th><th>Daily rate</th><th>Account email</th><th></th></tr></thead>
  <tbody>
   <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr>
    <td><?php echo e($employee->full_name); ?></td>
    <td><?php echo e($employee->position); ?></td>
    <td><?php echo e($employee->status); ?></td>
    <td><?php echo e(money($employee->daily_rate)); ?></td>
    <td><?php echo e($employee->user?->email ?: '—'); ?></td>
    <td>
     <a class="btn" href="<?php echo e(route('employees.edit', $employee)); ?>">Edit</a>
     <?php if($employee->status !== 'Resigned'): ?>
      <form method="POST" action="<?php echo e(route('employees.resign', $employee)); ?>" class="inline" onsubmit="return confirm('Mark this employee as resigned?')">
       <?php echo csrf_field(); ?>
       <button class="danger">Resign</button>
      </form>
     <?php endif; ?>
    </td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="6">No employees found.</td></tr>
   <?php endif; ?>
  </tbody>
 </table>
 <?php echo e($employees->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\employees\index.blade.php ENDPATH**/ ?>