<div class="grid">
 <div class="card"><div>Revenue this month</div><h2>&#8369;<?php echo e(number_format((float) $monthRevenue, 2)); ?></h2></div>
 <div class="card"><div>Completed sales this month</div><h2><?php echo e(number_format($monthTransactions)); ?></h2></div>
</div>
<div class="card">
 <a class="btn" href="<?php echo e(route('reports.sales')); ?>">View sales report</a>
</div>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\dashboard\_sales.blade.php ENDPATH**/ ?>