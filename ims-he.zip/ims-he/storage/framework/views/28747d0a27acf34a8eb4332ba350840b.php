<?php $__env->startSection('title','Edit product'); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:520px"><h3>Edit <?php echo e($product->product_name); ?></h3>
 <form method="POST" action="<?php echo e(route('products.update', $product)); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
  <?php if (isset($component)) { $__componentOriginal4b59d33ec22cba46f940a99fd296c352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b59d33ec22cba46f940a99fd296c352 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.required-note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required-note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $attributes = $__attributesOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__attributesOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b59d33ec22cba46f940a99fd296c352)): ?>
<?php $component = $__componentOriginal4b59d33ec22cba46f940a99fd296c352; ?>
<?php unset($__componentOriginal4b59d33ec22cba46f940a99fd296c352); ?>
<?php endif; ?>
  <?php echo $__env->make('products._fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <p><small>Changing the stock quantity here is recorded in the inventory log as an Adjustment.</small></p>
  <p><button>Save</button> <a class="btn" href="<?php echo e(route('products.index')); ?>">Cancel</a></p>
 </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/products/edit.blade.php ENDPATH**/ ?>