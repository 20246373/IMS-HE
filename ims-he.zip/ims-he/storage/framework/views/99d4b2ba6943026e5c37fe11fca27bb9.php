<?php $__env->startSection('title','Online orders'); ?>
<?php $__env->startSection('heading', 'Online Orders'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <form method="GET" action="<?php echo e(route('online-orders.index')); ?>" class="report-filter">
  <label>Status
  <select name="status">
   <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s); ?>" <?php if($status === $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <option value="All" <?php if($status === 'All'): echo 'selected'; endif; ?>>All statuses</option>
  </select>
  </label>
  <button>Filter</button>
 </form>

 <?php if($orders->isEmpty()): ?>
  <p><?php echo e($status === 'All' ? 'There are no online orders yet.' : "There are no {$status} online orders."); ?></p>
 <?php else: ?>
  <table class="cart-table">
   <tr><th>Order</th><th>Date</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Actions</th></tr>
   <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td>#<?php echo e($o->invoice_id); ?></td>
     <td><?php echo e($o->invoice_date->format('M d, Y')); ?></td>
     <td><?php echo e(trim(($o->customer?->first_name ?? '').' '.($o->customer?->last_name ?? '')) ?: ($o->customer?->email ?? 'Deleted account')); ?></td>
     <td><?php echo e($o->items_count); ?></td>
     <td><?php echo e(money($o->total_amount)); ?></td>
     <td><?php echo e($o->payment?->payment_method); ?></td>
     <td><?php echo $__env->make('orders._status', ['status' => $o->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
     <td><a href="<?php echo e(route('online-orders.show', $o)); ?>"><?php echo e($o->status === 'Pending' ? 'Review' : 'View'); ?></a></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php if($orders->hasPages()): ?>
   <p class="pager">
    <?php if($orders->onFirstPage()): ?><span>Previous</span><?php else: ?><a href="<?php echo e($orders->previousPageUrl()); ?>">Previous</a><?php endif; ?>
    <span>Page <?php echo e($orders->currentPage()); ?> of <?php echo e($orders->lastPage()); ?></span>
    <?php if($orders->hasMorePages()): ?><a href="<?php echo e($orders->nextPageUrl()); ?>">Next</a><?php else: ?><span>Next</span><?php endif; ?>
   </p>
  <?php endif; ?>
 <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/orders/manage/index.blade.php ENDPATH**/ ?>