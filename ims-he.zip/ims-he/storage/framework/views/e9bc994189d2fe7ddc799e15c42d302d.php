<?php $__env->startSection('title', 'Payroll details'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="report-heading">
  <div><h2>Payroll</h2><p><?php echo e($payroll->period_start->format('M d, Y')); ?> – <?php echo e($payroll->period_end->format('M d, Y')); ?> · <?php echo e($payroll->status); ?></p></div>
  <div>
   <a class="btn" href="<?php echo e(route('payrolls.download', $payroll)); ?>">Save as PDF</a>
   <?php if($payroll->status === 'Draft' && auth()->user()->hasRole('Treasurer')): ?>
    <form method="POST" action="<?php echo e(route('payrolls.finalize', $payroll)); ?>" class="inline"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button>Finalize</button></form>
    <form method="POST" action="<?php echo e(route('payrolls.destroy', $payroll)); ?>" class="inline" onsubmit="return confirm('Delete this draft payroll?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="danger">Delete draft</button></form>
   <?php endif; ?>
  </div>
 </div>
 <div class="report-summary"><div><strong>Gross</strong><span><?php echo e(money($payroll->total_gross)); ?></span></div><div><strong>Deductions</strong><span><?php echo e(money($payroll->total_deductions)); ?></span></div><div><strong>Net</strong><span><?php echo e(money($payroll->total_net)); ?></span></div></div>
 <table>
  <thead><tr><th>Employee</th><th>Days</th><th>OT hours</th><th>Gross</th><th>SSS</th><th>PhilHealth</th><th>Pag-IBIG</th><th>Tax</th><th>Deductions</th><th>Net</th></tr></thead>
  <tbody>
   <?php $__currentLoopData = $payroll->payslips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payslip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td><a href="<?php echo e(route('payrolls.payslip', [$payroll, $payslip])); ?>"><?php echo e($payslip->employee->full_name); ?></a></td>
     <td><?php echo e(number_format((float) $payslip->days_worked, 2)); ?></td><td><?php echo e(number_format((float) $payslip->overtime_hours, 2)); ?></td>
     <td><?php echo e(money($payslip->gross_pay)); ?></td><td><?php echo e(money($payslip->sss_deduction)); ?></td><td><?php echo e(money($payslip->philhealth_deduction)); ?></td><td><?php echo e(money($payslip->pagibig_deduction)); ?></td><td><?php echo e(money($payslip->tax_deduction)); ?></td><td><?php echo e(money($payslip->total_deductions)); ?></td><td><?php echo e(money($payslip->net_pay)); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
 </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\payroll\show.blade.php ENDPATH**/ ?>