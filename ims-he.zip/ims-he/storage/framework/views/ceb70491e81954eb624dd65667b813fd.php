<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('title', 'IMS-HE'); ?> - Ibay Enterprises</title>
<style>
 body{font-family:system-ui,sans-serif;margin:0;background:#f4f5f7;color:#222}
 nav{background:#1f3a5f;color:#fff;padding:.7rem 1.2rem;display:flex;gap:1rem;align-items:center;flex-wrap:wrap}
 nav a{color:#fff;text-decoration:none} nav .sp{flex:1}
 nav.staff-nav{position:fixed;z-index:20;inset:0 auto 0 0;width:248px;box-sizing:border-box;flex-direction:column;flex-wrap:nowrap;align-items:stretch;gap:.35rem;padding:1.5rem 1rem 1rem;background:linear-gradient(165deg,#172d49 0%,#1f3a5f 58%,#25466d 100%);box-shadow:8px 0 28px #14253a20;overflow-y:auto;overflow-x:hidden}
 nav.staff-nav > strong{display:flex;align-items:center;gap:.7rem;font-size:1.05rem;letter-spacing:.06em;padding:.3rem .65rem 1.45rem}
 nav.staff-nav > strong:before{content:"I";display:grid;place-items:center;width:34px;height:34px;border-radius:11px;background:#d8e8fb;color:#1f3a5f;font-size:1.05rem;font-weight:800;letter-spacing:0;box-shadow:0 3px 10px #071b3333}
 nav.staff-nav > a{display:flex;align-items:center;min-height:42px;padding:0 .8rem;border-radius:9px;color:#d9e4f1;font-size:.94rem;font-weight:500;transition:background .16s ease,color .16s ease,transform .16s ease}
 nav.staff-nav > a:hover,nav.staff-nav .nav-dropdown > div a:hover{background:#ffffff14;color:#fff;transform:translateX(2px)}
 nav.staff-nav > a.nav-link-active,nav.staff-nav .nav-dropdown > div a.nav-link-active{background:#dceafe;color:#19395e;font-weight:650;box-shadow:0 3px 10px #0c1e342b}
 nav.staff-nav .nav-section{padding:1rem .8rem .35rem;color:#9cb2cb;font-size:.68rem;font-weight:700;letter-spacing:.13em;text-transform:uppercase}
 nav.staff-nav .nav-sp{flex:1;min-height:1rem}
 nav.staff-nav .nav-dropdown{border-radius:9px}
 nav.staff-nav .nav-dropdown summary{position:relative;display:flex;align-items:center;min-height:42px;padding:0 2rem 0 .8rem;border-radius:9px;color:#d9e4f1;font-size:.94rem;font-weight:500;transition:background .16s ease,color .16s ease}
 nav.staff-nav .nav-dropdown summary:hover{background:#ffffff14;color:#fff}
 nav.staff-nav .nav-dropdown summary:after{content:"";position:absolute;right:.95rem;width:7px;height:7px;border-right:1.5px solid currentColor;border-bottom:1.5px solid currentColor;transform:rotate(45deg) translateY(-2px);transition:transform .16s ease}
 nav.staff-nav .nav-dropdown[open] summary:after{transform:rotate(225deg) translate(-1px,-1px)}
 nav.staff-nav .nav-dropdown > div{position:static;min-width:0;margin:.2rem 0 .35rem .8rem;padding:.25rem 0 .25rem .65rem;border-left:1px solid #ffffff30;box-shadow:none;background:transparent;gap:.15rem}
 nav.staff-nav .nav-dropdown > div a{display:flex;align-items:center;min-height:36px;padding:0 .7rem;border-radius:7px;color:#c2d1e3;font-size:.88rem;transition:background .16s ease,color .16s ease,transform .16s ease}
 nav.staff-nav .nav-user{display:grid;gap:.18rem;margin:.25rem 0 .55rem;padding:.8rem .85rem;border:1px solid #ffffff18;border-radius:10px;background:#ffffff0b}
 nav.staff-nav .nav-user strong{color:#fff;font-size:.88rem;font-weight:600}
 nav.staff-nav .nav-user span{color:#aebfd3;font-size:.76rem}
 nav.staff-nav form{margin:0}
 nav.staff-nav form button{width:100%;min-height:40px;background:#ffffff12;color:#e8eef6;text-align:left;padding:0 .85rem;border:1px solid #ffffff14;border-radius:9px;font-size:.9rem}
 nav.staff-nav form button:hover{background:#ffffff20;color:#fff}
 body.staff-layout main{width:calc(100% - 294px);max-width:1120px;margin:1.6rem 1.5rem 1.5rem 272px;padding:0}
 @media (max-width:700px){
  nav.staff-nav{width:210px;padding:1rem .8rem .8rem}
  body.staff-layout main{width:calc(100% - 236px);margin:1rem .8rem 1rem 222px}
 }
 @media (max-width:520px){
  nav.staff-nav{position:sticky;inset:auto;width:100%;height:auto;max-height:48vh;border-radius:0 0 16px 16px;padding:.7rem;gap:.2rem}
  nav.staff-nav > strong{padding:.1rem .55rem .55rem}
  nav.staff-nav .nav-section,nav.staff-nav .nav-sp,nav.staff-nav .nav-user{display:none}
  nav.staff-nav > a,nav.staff-nav .nav-dropdown summary{min-height:36px;font-size:.88rem}
  nav.staff-nav .nav-dropdown > div{margin-left:.55rem}
  nav.staff-nav form button{min-height:36px}
  body.staff-layout main{width:auto;max-width:none;margin:1rem .8rem;padding:0}
 }
 .nav-dropdown{position:relative}
 .nav-dropdown summary{cursor:pointer;list-style:none}
 .nav-dropdown summary::-webkit-details-marker{display:none}
 .nav-dropdown > div{position:absolute;z-index:10;top:calc(100% + .7rem);left:0;min-width:10rem;background:#1f3a5f;padding:.7rem;display:grid;gap:.7rem;border-radius:0 0 5px 5px;box-shadow:0 2px 6px #0003}
 main{max-width:1000px;margin:1.2rem auto;padding:0 1rem}
 .card{background:#fff;border-radius:8px;padding:1rem 1.2rem;margin-bottom:1rem;box-shadow:0 1px 3px #0001}
 table{width:100%;border-collapse:collapse} th,td{padding:.45rem .5rem;border-bottom:1px solid #eee;text-align:left}
 input,select,textarea{padding:.4rem;margin:.2rem 0;max-width:100%} label{display:block;margin-top:.5rem;font-size:.9rem}
 .form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem 1rem}
 .field{min-width:0}.field label{margin:0 0 .25rem}.field input,.field select,.field textarea{box-sizing:border-box;width:100%;height:2.35rem;margin:0}
 .field textarea{height:auto;min-height:5rem}.required:after{content:" *";color:#b42318}.optional{color:#555}.optional:after{content:" (optional)";color:#777;font-weight:400}
 .input-with-prefix{display:flex;align-items:center;box-sizing:border-box;border:1px solid #767676;border-radius:3px;background:#fff}
 .input-with-prefix > span{padding:0 .45rem;color:#555;font-size:.9rem}
 .input-with-prefix input{box-sizing:border-box;width:100%;min-width:0;height:2.35rem;margin:0;border:0;background:transparent}
 input[readonly],textarea[readonly]{background:#eef0f3;color:#666}.field-error{margin-top:.25rem;color:#b42318;font-size:.82rem}
 .required-note{margin:.2rem 0 1rem;color:#555;font-size:.88rem}.required-note span{font-weight:600}
 .alert{display:flex;align-items:flex-start;gap:.7rem;padding:.75rem 1rem;margin-bottom:1rem;border:1px solid;border-radius:7px}.alert-success{background:#e8f7ed;border-color:#98d5aa;color:#176b35}.alert-error{background:#fcedeb;border-color:#e7a39c;color:#8a1f17}.alert-warning{background:#fff5d8;border-color:#e8c66d;color:#785b00}.alert-icon svg{display:block;width:1.2rem;height:1.2rem}.alert-body{flex:1}.alert-body strong{display:block;margin-bottom:.15rem}.alert-body ul{margin:.25rem 0 0;padding-left:1.2rem}.alert-dismiss{padding:0;background:transparent;color:currentColor;font-size:1.2rem;line-height:1;border:0}
 @media (max-width:700px){.form-grid{grid-template-columns:1fr}}
 button,.btn{background:#1f3a5f;color:#fff;border:0;border-radius:5px;padding:.45rem .9rem;cursor:pointer;text-decoration:none;display:inline-block}
 .danger{background:#a33}.ok{background:#e6f4ea;padding:.6rem;border-radius:5px;margin-bottom:1rem}
 .err{background:#fdecea;padding:.6rem;border-radius:5px;margin-bottom:1rem;color:#8a1f17}
 .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1rem}.low{color:#a33;font-weight:600}
 .inline{display:inline;margin:0}
 /* Login: access chooser + forms, built on .card */
 .auth{max-width:400px;margin:auto} .auth h2{margin-top:0}
 .auth-top{display:flex;justify-content:space-between;font-size:.9rem;color:#666;margin-bottom:.4rem}
 .auth-top a{color:#1f3a5f;text-decoration:none}
 .auth input{display:block;width:100%;box-sizing:border-box}
 .auth .btn{display:block;text-align:center;margin-bottom:.5rem}
 .btn-alt{background:#fff;color:#1f3a5f;border:1px solid #1f3a5f}
 /* Storefront (Product Catalog Module) */
 .search{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center} .search input{flex:1;min-width:180px}
 .cats a{display:inline-block;margin:.2rem .4rem .2rem 0;padding:.2rem .6rem;border:1px solid #1f3a5f;border-radius:999px;color:#1f3a5f;text-decoration:none;font-size:.85rem}
 .product{display:flex;flex-direction:column;gap:.25rem;color:inherit;text-decoration:none;margin:0} .product:hover{box-shadow:0 2px 8px #0002}
 .product img,.product .noimg{width:100%;height:150px;object-fit:cover;border-radius:5px}
 .noimg{background:#eef0f3;color:#888;display:flex;align-items:center;justify-content:center;font-size:.85rem}
 .product small,.detail small{color:#666}
 .stock{font-size:.8rem;font-weight:600;padding:.1rem .5rem;border-radius:999px;align-self:flex-start}
 .stock.in{background:#e6f4ea;color:#1e6b34} .stock.out{background:#fdecea;color:#8a1f17} .stock.low{background:#fff5d8;color:#785b00}
 .brand{margin:.2rem 0;color:#555}
 /* Storefront on phones: two product columns, filters stacked full width, wide tables scroll sideways */
 @media (max-width:520px){
  .grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:.6rem}
  .product img,.product .noimg{height:110px}
  .search > *{flex:1 1 100%} .search input{min-width:0}
  .cart-table{display:block;overflow-x:auto}
 }
 /* Order status badges (orders/_status) */
 .status{display:inline-block;font-size:.8rem;font-weight:600;padding:.1rem .55rem;border-radius:999px;background:#eef0f3;color:#333}
 .status-pending{background:#fff5d8;color:#785b00} .status-completed{background:#e6f4ea;color:#1e6b34} .status-cancelled{background:#fdecea;color:#8a1f17}
 .detail{display:grid;grid-template-columns:minmax(0,320px) 1fr;gap:1.2rem} .detail img,.detail .noimg{width:100%;height:280px;object-fit:cover;border-radius:5px}
 .detail h2{margin:.2rem 0} .price{font-size:1.3rem;font-weight:600;margin:.3rem 0}
 @media (max-width:600px){.detail{grid-template-columns:1fr}}
 .pager{display:flex;gap:1rem;justify-content:center;align-items:center} .pager span{color:#888}
 /* Cart */
 .qty{display:flex;gap:.4rem;align-items:center;flex-wrap:wrap;margin:0} .qty label{margin:0}
 .cart-table th,.cart-table td{text-align:center;vertical-align:middle} .cart-table .qty{justify-content:center}
 .cart-table tr > :first-child{text-align:left}   /* Product column stays left-aligned */
 .cart-table .cart-total-row th:first-child{text-align:right}   /* "Total" label sits next to the amount */
 .report-heading{display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap}
 .report-heading h2{margin:.2rem 0}
 .report-filter{display:flex;align-items:end;gap:.8rem;flex-wrap:wrap;margin:1rem 0}
 .report-filter label{margin:0}
 .report-summary{display:flex;gap:1rem;flex-wrap:wrap;margin:1rem 0}
 .report-summary > div{background:#f4f5f7;border-radius:5px;padding:.7rem 1rem;min-width:11rem;display:grid;gap:.3rem}
 .stepper{display:inline-flex;align-items:stretch;border:1px solid #ccc;border-radius:5px;overflow:hidden;background:#fff}
 .stepper button{background:#eef0f3;color:#1f3a5f;border-radius:0;padding:.3rem .7rem;font-size:1rem;font-weight:600}
 .stepper button:hover{background:#dde2e8}
 .stepper input{width:3.5rem;margin:0;border:0;border-left:1px solid #ccc;border-right:1px solid #ccc;text-align:center;-moz-appearance:textfield}
 .stepper input::-webkit-outer-spin-button,.stepper input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
</style>
<?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="<?php if(auth()->guard('web')->check()): ?> staff-layout <?php endif; ?>">
<nav <?php if(auth()->guard('web')->check()): ?> class="staff-nav" <?php endif; ?>>
    <strong>IMS-HE</strong>

    <?php if(auth()->guard('web')->check()): ?>
        <?php
            $user = auth()->user();

            $isAdministrator = $user->hasRole('Administrator');
            $isPresident = $user->hasRole('President');
            $isTreasurer = $user->hasRole('Treasurer');
            $isInventoryClerk = $user->hasRole('Inventory Clerk');
            $isSupervisor = $user->hasRole('Store Supervisor');
            $isEmployee = $user->hasRole('Employees');

            $canManageInventory =
                $isPresident || $isInventoryClerk || $isSupervisor;

            $canManageProcurement =
                $isPresident || $isInventoryClerk || $isSupervisor;

            $canViewSalesReports =
                $isPresident || $isTreasurer || $isSupervisor;

            $canViewInventoryReports =
                $isPresident || $isInventoryClerk || $isSupervisor;

            $canViewProcurementReports =
                $isPresident || $isInventoryClerk;
            $canViewFinancialReports = $isPresident || $isTreasurer;
            $canViewLedger = $isPresident || $isTreasurer || $isSupervisor;
            $canManageEmployees = $isPresident || $isTreasurer;

            $canExport =
                $isAdministrator || $isPresident || $isTreasurer || $isInventoryClerk || $isSupervisor;
        ?>

        
        <span class="nav-section">Workspace</span>

        <?php if (! ($user->isPending())): ?>
        <a class="<?php echo e(request()->routeIs('dashboard') ? 'nav-link-active' : ''); ?>"
           href="<?php echo e(route('dashboard')); ?>">
            Dashboard
        </a>
        <?php endif; ?>

        
        <?php if($user->hasRole(\App\Models\User::PRESIDENT, \App\Models\User::STORE_SUPERVISOR, \App\Models\User::EMPLOYEE)): ?>
            <a class="<?php echo e(request()->routeIs('online-orders.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('online-orders.index')); ?>">
                Online Orders
            </a>
        <?php endif; ?>

        <?php if($user->hasRole(\App\Models\User::STORE_SUPERVISOR, \App\Models\User::EMPLOYEE)): ?>
            <a class="<?php echo e(request()->routeIs('sales.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('sales.create')); ?>">
                Sales (POS)
            </a>
        <?php endif; ?>

        <?php if($user->hasRole(\App\Models\User::EMPLOYEE)): ?>
            <a class="<?php echo e(request()->routeIs('attendance.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('attendance.my')); ?>">Attendance</a>
        <?php elseif($user->hasRole(\App\Models\User::STORE_SUPERVISOR, \App\Models\User::TREASURER)): ?>
            <a class="<?php echo e(request()->routeIs('attendance.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('attendance.day')); ?>">Attendance</a>
        <?php endif; ?>

        <?php if($user->hasRole(\App\Models\User::PRESIDENT, \App\Models\User::TREASURER)): ?>
            <a class="<?php echo e(request()->routeIs('payrolls.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('payrolls.index')); ?>">Payroll</a>
        <?php endif; ?>

        <?php if($user->hasRole(\App\Models\User::PRESIDENT, \App\Models\User::STORE_SUPERVISOR)): ?>
            <a class="<?php echo e(request()->routeIs('customers.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('customers.index')); ?>">Customers</a>
        <?php endif; ?>

        
        <?php if($canManageInventory): ?>
            <details class="nav-dropdown"
                <?php echo e(request()->routeIs('products.*', 'categories.*', 'stock.*') ? 'open' : ''); ?>>
                <summary>Inventory</summary>
                <div>
                    <a class="<?php echo e(request()->routeIs('products.*') ? 'nav-link-active' : ''); ?>"
                       href="<?php echo e(route('products.index')); ?>">
                        Products
                    </a>

                    <a class="<?php echo e(request()->routeIs('categories.*') ? 'nav-link-active' : ''); ?>"
                       href="<?php echo e(route('categories.index')); ?>">
                        Categories
                    </a>

                    <a class="<?php echo e(request()->routeIs('stock.*') ? 'nav-link-active' : ''); ?>"
                       href="<?php echo e(route('stock.index')); ?>">
                        Stock
                    </a>
                </div>
            </details>
        <?php endif; ?>

        
        <?php if($canManageProcurement): ?>
            <span class="nav-section">Operations</span>

            <a class="<?php echo e(request()->routeIs('suppliers.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('suppliers.index')); ?>">
                Suppliers
            </a>

            <a class="<?php echo e(request()->routeIs('purchase-orders.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('purchase-orders.index')); ?>">
                Purchase Orders
            </a>

            <a class="<?php echo e(request()->routeIs('deliveries.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('deliveries.create')); ?>">
                Receive Delivery
            </a>
        <?php endif; ?>

        
        <?php if($canViewSalesReports || $canViewInventoryReports || $canViewProcurementReports || $canViewFinancialReports): ?>
            <details class="nav-dropdown"
                <?php echo e(request()->routeIs('reports.*') ? 'open' : ''); ?>>
                <summary>Reports</summary>
                <div>
                    <?php if($canViewSalesReports): ?>
                        <a class="<?php echo e(request()->routeIs('reports.sales*') ? 'nav-link-active' : ''); ?>"
                           href="<?php echo e(route('reports.sales')); ?>">
                            Sales Report
                        </a>
                    <?php endif; ?>

                    <?php if($canViewInventoryReports): ?>
                        <a class="<?php echo e(request()->routeIs('reports.inventory*') ? 'nav-link-active' : ''); ?>"
                           href="<?php echo e(route('reports.inventory')); ?>">
                            Inventory Report
                        </a>
                    <?php endif; ?>

                    <?php if($canViewProcurementReports): ?>
                        <a class="<?php echo e(request()->routeIs('reports.procurement*') ? 'nav-link-active' : ''); ?>"
                           href="<?php echo e(route('reports.procurement')); ?>">
                            Procurement Report
                        </a>
                    <?php endif; ?>

                    <?php if($isPresident || $isTreasurer): ?>
                        <a class="<?php echo e(request()->routeIs('reports.financial*') ? 'nav-link-active' : ''); ?>"
                           href="<?php echo e(route('reports.financial')); ?>">Financial Reports</a>
                    <?php endif; ?>
                </div>
            </details>
        <?php endif; ?>

        <?php if($canViewLedger): ?>
            <a class="<?php echo e(request()->routeIs('ledger.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('ledger.index')); ?>">Ledger</a>
        <?php endif; ?>

        <?php if($canManageEmployees): ?>
            <a class="<?php echo e(request()->routeIs('employees.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('employees.index')); ?>">Employees</a>
        <?php endif; ?>

        
        <?php if($isAdministrator): ?>
            <span class="nav-section">Administration</span>

            <a class="<?php echo e(request()->routeIs('users.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('users.index')); ?>">
                User Accounts
            </a>

            <a class="<?php echo e(request()->routeIs('audit.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('audit.index')); ?>">
                Audit Log
            </a>
        <?php endif; ?>

        <?php if($canExport): ?>
            <a class="<?php echo e(request()->routeIs('exports.*') ? 'nav-link-active' : ''); ?>"
               href="<?php echo e(route('exports.index')); ?>">
                Export Center
            </a>
        <?php endif; ?>

        
        <span class="nav-sp"></span>

        <div class="nav-user">
            <strong><?php echo e($user->label()); ?></strong>
            <span><?php echo e($user->role); ?></span>
        </div>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">Logout</button>
        </form>

    <?php elseif(auth()->guard('customer')->check()): ?>

        
        <a href="<?php echo e(route('home')); ?>">Home</a>
        <a href="<?php echo e(route('catalog.index')); ?>">Products</a>

        <a href="<?php echo e(route('customer.cart.index')); ?>">
            Cart (
            <span id="cart-count">
                <?php echo e(auth('customer')->user()->cart?->items()->sum('quantity') ?? 0); ?>

            </span>
            )
        </a>

        <a href="<?php echo e(route('customer.orders.index')); ?>">My Orders</a>
        <a href="<?php echo e(route('customer.account')); ?>">My Account</a>

        <span class="sp"></span>

        <span><?php echo e(auth('customer')->user()->display_name); ?></span>

        <form method="POST"
              action="<?php echo e(route('customer.logout')); ?>"
              class="inline">
            <?php echo csrf_field(); ?>
            <button type="submit">Logout</button>
        </form>

    <?php else: ?>

        
        <a href="<?php echo e(route('home')); ?>">Home</a>
        <a href="<?php echo e(route('catalog.index')); ?>">Products</a>

        <span class="sp"></span>

        <a href="<?php echo e(route('customer.register')); ?>">Sign Up</a>
        <a href="<?php echo e(route('login')); ?>">Log In</a>

    <?php endif; ?>
</nav>

<?php echo $__env->yieldContent('hero'); ?>
<main>
 <?php if(session('status')): ?><?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success','title' => 'Success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','title' => 'Success']); ?><?php echo e(session('status')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?><?php endif; ?>
 <?php if(session('warning')): ?><?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'warning','title' => 'Warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning','title' => 'Warning']); ?><?php echo e(session('warning')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?><?php endif; ?>
 <?php if($errors->any()): ?>
  <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error','title' => 'Please correct the following']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','title' => 'Please correct the following']); ?>
   <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
 <?php endif; ?>
 <?php echo $__env->yieldContent('content'); ?>
</main>
<script>
 // Quantity steppers (partials/qty): - / + stay within the input's min and max (available stock).
 document.addEventListener('click', function (e) {
  var btn = e.target.closest('.stepper [data-step]');
  if (!btn) return;
  var input = btn.parentElement.querySelector('input');
  var min = Number(input.min) || 1, max = Number(input.max) || Infinity;
  var next = (Number(input.value) || min) + Number(btn.dataset.step);
  input.value = Math.min(max, Math.max(min, next));
  input.dispatchEvent(new Event('input', { bubbles: true }));   // lets pages react, e.g. the cart's auto-update
 });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\layouts\app.blade.php ENDPATH**/ ?>