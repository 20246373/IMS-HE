<div class="grid">
 <a class="card card-link" href="<?php echo e(route('reports.sales')); ?>"><div>Revenue this month</div><h2><?php echo e(money($monthRevenue)); ?></h2></a>
 <a class="card card-link" href="<?php echo e(route('reports.sales')); ?>"><div>Completed sales this month</div><h2><?php echo e(number_format($monthTransactions)); ?></h2></a>
</div>
<?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views/dashboard/_sales.blade.php ENDPATH**/ ?>