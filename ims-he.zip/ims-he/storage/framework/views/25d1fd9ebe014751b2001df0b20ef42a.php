<?php $__env->startSection('title','Purchase Orders'); ?>
<?php $__env->startPush('head'); ?>
<style>
 .badge{display:inline-block;margin-left:.35rem;padding:.12rem .5rem;border-radius:999px;background:#eef0f3;color:#333;font-size:.72rem;font-weight:700;line-height:1.2;vertical-align:middle}
 .badge.amber{background:#fff5d8;color:#785b00}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem">
  <h2>Purchase Orders</h2>
  <a class="btn" href="<?php echo e(route('purchase-orders.create')); ?>">+ New purchase order</a>
 </div>
 <table>
  <tr><th>PO</th><th>Supplier</th><th>Date</th><th>Status</th><th>Total</th><th></th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
   <td>#<?php echo e($purchaseOrder->po_id); ?></td>
   <td><?php echo e($purchaseOrder->supplier->supplier_name); ?></td>
   <td><?php echo e($purchaseOrder->order_date->format('M d, Y')); ?></td>
   <td>
    <?php echo e($purchaseOrder->status); ?>

    <?php if($purchaseOrder->is_auto): ?><span class="badge amber">Auto</span><?php endif; ?>
   </td>
   <td><?php echo e(money($purchaseOrder->items->sum('subtotal'))); ?></td>
   <td><a class="btn" href="<?php echo e(route('purchase-orders.show', $purchaseOrder)); ?>">View</a></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="6">No purchase orders found.</td></tr>
  <?php endif; ?>
 </table>
 <?php echo e($purchaseOrders->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\purchase-orders\index.blade.php ENDPATH**/ ?>