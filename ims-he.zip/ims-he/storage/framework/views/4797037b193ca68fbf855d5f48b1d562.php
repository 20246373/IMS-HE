<?php $__env->startSection('title','Suppliers'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
 <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem">
  <h2>Suppliers</h2>
  <a class="btn" href="<?php echo e(route('suppliers.create')); ?>">+ Add supplier</a>
 </div>
 <table>
  <tr><th>Name</th><th>Contact number</th><th>Address</th><th>Purchase orders</th><th></th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
   <td><?php echo e($supplier->supplier_name); ?></td>
   <td><?php echo e($supplier->contact_number); ?></td>
   <td><?php echo e($supplier->address); ?></td>
   <td><?php echo e($supplier->purchase_orders_count); ?></td>
   <td>
    <a class="btn" href="<?php echo e(route('suppliers.edit', $supplier)); ?>">Edit</a>
    <form method="POST" action="<?php echo e(route('suppliers.destroy', $supplier)); ?>" class="inline" onsubmit="return confirm('Are you sure you want to delete this record? This action cannot be undone.')">
     <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
     <?php if(auth()->user()->hasRole('President')): ?><button class="danger">Delete</button><?php endif; ?>
    </form>
   </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="5">No suppliers found.</td></tr>
  <?php endif; ?>
 </table>
 <?php echo e($suppliers->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\suppliers\index.blade.php ENDPATH**/ ?>