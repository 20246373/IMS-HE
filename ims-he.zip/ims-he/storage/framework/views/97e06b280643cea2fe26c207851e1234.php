<?php $__env->startSection('title','Order placed'); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:640px">
 <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success','title' => 'Order placed']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','title' => 'Order placed']); ?>Thank you! Your order #<?php echo e($invoice->invoice_id); ?> has been received. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

 <table>
  <tr><th>Order number</th><td>#<?php echo e($invoice->invoice_id); ?></td></tr>
  <tr><th>Date</th><td><?php echo e($invoice->invoice_date->format('M d, Y')); ?></td></tr>
  <tr><th>Items</th><td><?php echo e($invoice->items->sum('quantity')); ?></td></tr>
  <tr><th>Total</th><td><strong><?php echo e(money($invoice->total_amount)); ?></strong></td></tr>
  <tr><th>Payment method</th><td><?php echo e($invoice->payment?->payment_method); ?></td></tr>
  <tr><th>Status</th><td><?php echo $__env->make('orders._status', ['status' => $invoice->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td></tr>
 </table>

 <h3>What happens next</h3>
 <p>The store will contact you at <strong><?php echo e($invoice->customer->contact_number); ?></strong> to arrange payment and pickup or delivery to <strong><?php echo e($invoice->customer->address); ?></strong>. You can follow the status in My orders.</p>

 <p>
  <a class="btn" href="<?php echo e(route('customer.orders.show', $invoice)); ?>">View receipt</a>
  <a class="btn btn-alt" href="<?php echo e(route('customer.orders.index')); ?>">My orders</a>
  <a href="<?php echo e(route('catalog.index')); ?>">Continue shopping</a>
 </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Users\llore\Documents\GITHUB\IMS-HE\ims-he\resources\views\orders\confirmation.blade.php ENDPATH**/ ?>